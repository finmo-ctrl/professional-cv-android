PROFESSIONAL CV — PANDUAN SINGKAT (WINDOWS 7)

Project ini dibuat agar source code dapat diedit menggunakan Sublime Text pada Windows 7.
Komputer Windows 7 TIDAK perlu memasang Flutter SDK, Android SDK, Java JDK, Gradle,
Android Studio, atau Visual Studio. Kompilasi APK dikerjakan pada server Codemagic.

LANGKAH:
1. Extract file PROFESSIONAL_CV_FLUTTER_SOURCE.zip.
2. Buka folder Professional_CV_Flutter menggunakan Sublime Text.
3. Edit source code di folder lib/ dan data website di assets/data/cv_data.json.
4. Seluruh aset gambar di assets/images/ berformat JPG.
5. Buat repository GitHub melalui browser dan upload SELURUH ISI folder project
   (bukan ZIP sebagai satu file) ke root repository.
6. Hubungkan repository GitHub ke Codemagic.
7. Jalankan workflow professional-cv-android pada codemagic.yaml.
8. Setelah seluruh pemeriksaan dan build berhasil, download app-debug.apk dari Artifacts.
9. Transfer APK ke HP Android dan install.

BAHASA:
English adalah default pada instalasi baru. Pilihan bahasa manual tersedia:
English, Bahasa Indonesia, Japanese, Korean, Simplified Chinese, German, Thai.
Pilihan bahasa disimpan di perangkat.

PAKLARING:
Ada 10 slot dokumen. Dokumen JPG dipilih dari HP dan disimpan secara lokal di folder
privat aplikasi. Dokumen ini tidak dikirim ke Firebase.

CATATAN:
- Nama, perusahaan, periode kerja, pendidikan, email, dan WhatsApp yang kosong pada
  website sumber tetap kosong sampai data asli diverifikasi.
- Foto sampel website harus diganti dengan foto milik sendiri/berizin sebelum APK
  dibagikan kepada umum.
- Firebase belum aktif sampai URL database dan aturan keamanannya dikonfigurasi.
- APK pertama adalah debug APK untuk pengujian, bukan release Play Store.
- Build Flutter, static analysis, test, dan instalasi perangkat belum dijalankan dari
  komputer ini karena Flutter SDK tidak terpasang. Codemagic workflow menyiapkan dan
  menjalankannya di cloud.
