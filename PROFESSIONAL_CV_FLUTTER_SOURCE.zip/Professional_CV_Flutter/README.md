# Professional CV — Flutter Android Source

This project converts the content and image assets from the supplied `cv_portfolio_professional(3).zip` website archive into an offline-first Flutter Android application.

## Product decisions

- Application name: **Professional CV**.
- Default language on a fresh installation: **English**. The app does not automatically follow the phone language.
- Manual interface languages: English, Indonesian, Japanese, Korean, Simplified Chinese, German, and Thai.
- Interface labels, navigation, common actions, settings, and document-management labels are localized. The detailed employment and training narratives are retained in the original English wording from the website to avoid inventing or silently mistranslating career claims. Product catalogue translations supplied by the website are reused for Indonesian, Japanese, Korean, and Simplified Chinese; German and Thai product descriptions fall back to English.
- Offline-first content: profile, experience, education, training, skills, portfolio images, product catalogue, and PDF CV generation.
- Local database: SQLite stores the metadata for up to 10 employment-certificate JPG files.
- Employment certificates (Paklaring) are selected by the owner from the phone and stored in the app-private document folder. The documents are not uploaded to Firebase.
- Firebase Realtime Database REST helper is included as an optional integration point. No Firebase project URL, credentials, or security rules are supplied or activated in this source package.
- Website sample certificate artwork is not used as proof of employment. The Paklaring screen starts with 10 empty private document slots.

## Image format policy

All raster image assets in `assets/images/` are **actual JPEG files with the `.jpg` extension**. The 79 PNG source files in the website archive were converted to JPEG. Where the source archive contained both a JPG and a PNG with the same base filename, the converted PNG version is retained with `-png.jpg` so that no existing JPG is overwritten. The application only references local JPG assets; it does not need PHP `media.php` routes to render images.

`ASSET-MANIFEST.json` records the source archive and image conversion count. The JPG images are bundled into the APK, so profile and portfolio visuals remain available offline.

## Website content imported

The app reads `assets/data/cv_data.json`, extracted from the authenticated website configuration `assets/js/config.php` in the supplied archive.

| Website content | Imported records |
|---|---:|
| Work experience | 10 |
| Training programmes | 4 |
| Core competency groups | 6 |
| Software/tool groups | 5 |
| Design portfolio visuals | 40 |
| Digital project descriptions | 3 |
| Gallery captions | 50 |
| Store categories | 20 |

The source website contains blank personal details such as name, company names, dates, education institution, email, and WhatsApp. These fields remain blank or display a verification placeholder. No missing personal facts have been fabricated.

Some portrait and gallery assets in the website archive are explicitly illustrative samples. Replace them with photographs you own or are authorised to use before publicly distributing the APK.

## Project structure

```text
professional_cv/
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── app_state.dart
│   ├── app_routes.dart
│   ├── data/
│   ├── l10n/
│   ├── screens/
│   ├── services/
│   └── widgets/
├── assets/
│   ├── data/cv_data.json
│   └── images/              # JPG only
├── scripts/
├── test/
├── pubspec.yaml
└── codemagic.yaml
```

## Editing with Sublime Text on Windows 7

Windows 7 is used only as the source-code editing computer. Do not install Flutter, Android SDK, Java JDK, Gradle, or Android Studio on that computer for this cloud-build workflow.

1. Extract this ZIP file.
2. Open the extracted `Professional_CV_Flutter` folder in Sublime Text.
3. Edit Dart files under `lib/`.
4. Edit the imported website data in `assets/data/cv_data.json`.
5. Replace images under `assets/images/` using genuine JPG files and keep the referenced filenames, or update the corresponding paths in the source.
6. Keep paklaring documents out of `assets/` unless you deliberately want them bundled inside every copy of the APK. The recommended approach is to add them from the installed app so they stay in that device's private storage.

The Dart SDK constraint is pinned to `>=3.2.0 <3.4.0` for the Flutter 3.19.6 cloud build configuration. Flutter 3.19/Dart 3.3 ended official Windows 7/8 host support; this project avoids that local limitation by running the build on Codemagic's Linux build machine. The Windows 7 computer is only used to edit files and upload the project.

## Build an installable APK without local SDK downloads

The included `codemagic.yaml` creates the Android platform folder on the cloud build machine, runs `scripts/validate_project.py`, fetches Flutter packages, runs Flutter static analysis and tests, and builds a debug APK. This is intended for personal device testing and can be installed on an Android phone. It is not a Play Store release build.

1. Create a GitHub repository using a web browser.
2. Upload the contents of this project folder to the repository root. Do not upload the ZIP as a single file; upload the extracted files and folders.
3. Create or sign in to a Codemagic account and connect that GitHub repository.
4. Select the `professional-cv-android` workflow from `codemagic.yaml` and start a build.
5. When the build passes, download `app-debug.apk` from the Codemagic artifacts.
6. Transfer the APK to the Android phone and install it. Android may ask you to allow installation from that source.

A debug APK is suitable for testing. For long-term updates, configure a persistent Android release keystore in Codemagic and build a signed release APK. Keep that keystore and its passwords private; losing it can prevent seamless updates over an already installed release build.

## Optional Firebase Realtime Database REST setup

The app currently works without Firebase. To configure the REST helper later:

1. Create a Firebase project and Realtime Database.
2. Review and configure restrictive database rules. Do not enable public write access to personal data.
3. In Codemagic, add `FIREBASE_DATABASE_URL` as an environment variable containing the database URL.
4. The provided build command passes that value through `--dart-define`.
5. Use `FirebaseRestService` for explicitly designed public-data reads or authenticated writes. Do not upload employment certificates, personal identifiers, or private documents to a public database path.

No Firebase API key, service-account key, password, or private token is embedded in this project.

## Important verification before public use

- Fill in and verify the profile name, contact details, company names, employment periods, education details, and training dates in `assets/data/cv_data.json`.
- Replace illustrative profile/gallery images with authentic images you are authorised to share.
- Add only genuine employment certificate images in JPG format to the 10 Paklaring slots from inside the installed application.
- Review all CV content before exporting or submitting the PDF.
- The generated PDF CV uses the English source career content. The seven-language setting currently localizes the app interface; it does not yet provide certified translations of every job-description paragraph.

## Validation boundary

The source package is checked for valid JSON/YAML, local image existence, JPEG file signatures, JPG-only asset extensions, content record counts, required source files, and basic localization tests. A Flutter SDK is not installed in this workspace, so a real `flutter analyze`, `flutter test`, Gradle build, and device installation cannot be truthfully reported as completed here. Those checks are configured to run automatically in the Codemagic workflow before the APK artifact is produced.
