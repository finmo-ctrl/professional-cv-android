import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'app_routes.dart';
import 'app_state.dart';
import 'data/cv_repository.dart';
import 'l10n/app_strings.dart';
import 'screens/about_screen.dart';
import 'screens/contact_screen.dart';
import 'screens/cv_screen.dart';
import 'screens/experience_screen.dart';
import 'screens/home_screen.dart';
import 'screens/learning_screen.dart';
import 'screens/more_screen.dart';
import 'screens/paklaring_screen.dart';
import 'screens/portfolio_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/skills_screen.dart';
import 'screens/store_screen.dart';

class ProfessionalCvApp extends StatelessWidget {
  const ProfessionalCvApp({super.key, required this.state, required this.data});
  final AppState state;
  final CvRepository data;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        final brightness = state.darkMode ? Brightness.dark : Brightness.light;
        final colorScheme = ColorScheme.fromSeed(
          seedColor: const Color(0xFF19385F),
          brightness: brightness,
        );
        return MaterialApp(
          title: 'Professional CV',
          debugShowCheckedModeBanner: false,
          locale: state.language == 'zh' ? const Locale('zh', 'CN') : Locale(state.language),
          supportedLocales: AppStrings.supportedLanguages.keys.map((code) =>
              code == 'zh' ? const Locale('zh', 'CN') : Locale(code)).toList(),
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          themeMode: state.darkMode ? ThemeMode.dark : ThemeMode.light,
          theme: _buildTheme(colorScheme, Brightness.light),
          darkTheme: _buildTheme(colorScheme, Brightness.dark),
          home: AppShell(state: state, data: data),
        );
      },
    );
  }

  ThemeData _buildTheme(ColorScheme colorScheme, Brightness brightness) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      brightness: brightness,
      scaffoldBackgroundColor: brightness == Brightness.light ? const Color(0xFFF5F7FA) : const Color(0xFF101820),
      appBarTheme: AppBarTheme(
        backgroundColor: brightness == Brightness.light ? const Color(0xFFF5F7FA) : const Color(0xFF101820),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        titleTextStyle: TextStyle(color: colorScheme.onSurface, fontSize: 18, fontWeight: FontWeight.w800),
      ),
      cardTheme: CardTheme(
        color: brightness == Brightness.light ? Colors.white : const Color(0xFF1B2733),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: colorScheme.surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: colorScheme.outlineVariant)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: brightness == Brightness.light ? Colors.white : const Color(0xFF1B2733),
        indicatorColor: colorScheme.primaryContainer,
        elevation: 0,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: colorScheme.surfaceVariant,
        side: BorderSide.none,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.state, required this.data});
  final AppState state;
  final CvRepository data;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  String _route = AppRoute.home;

  void _navigate(String route) {
    if (!mounted) return;
    setState(() => _route = route);
  }

  String _title() {
    final keys = <String, String>{
      AppRoute.home: 'home', AppRoute.about: 'about', AppRoute.experience: 'experience',
      AppRoute.paklaring: 'paklaring', AppRoute.education: 'educationTraining', AppRoute.skills: 'skills',
      AppRoute.portfolio: 'portfolio', AppRoute.store: 'store', AppRoute.cv: 'downloadCv',
      AppRoute.contact: 'contact', AppRoute.settings: 'settings', AppRoute.more: 'more',
    };
    return AppStrings.text(widget.state.language, keys[_route] ?? 'appName');
  }

  Widget _page() {
    final data = widget.data;
    final state = widget.state;
    switch (_route) {
      case AppRoute.about:
        return AboutScreen(data: data, state: state);
      case AppRoute.experience:
        return ExperienceScreen(data: data, state: state);
      case AppRoute.paklaring:
        return PaklaringScreen(state: state);
      case AppRoute.education:
        return LearningScreen(data: data, state: state);
      case AppRoute.skills:
        return SkillsScreen(data: data, state: state);
      case AppRoute.portfolio:
        return PortfolioScreen(data: data, state: state);
      case AppRoute.store:
        return StoreScreen(data: data, state: state);
      case AppRoute.cv:
        return CvScreen(data: data, state: state);
      case AppRoute.contact:
        return ContactScreen(data: data, state: state);
      case AppRoute.settings:
        return SettingsScreen(state: state);
      case AppRoute.more:
        return MoreScreen(state: state, onNavigate: _navigate);
      case AppRoute.home:
      default:
        return HomeScreen(data: data, state: state, onNavigate: _navigate);
    }
  }

  int get _selectedNavigationIndex {
    if (_route == AppRoute.experience) return 1;
    if (_route == AppRoute.portfolio) return 2;
    if (_route == AppRoute.more || _route == AppRoute.home) return _route == AppRoute.home ? 0 : 3;
    return 3;
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    return Scaffold(
      appBar: AppBar(
        title: Text(_title()),
        actions: [
          PopupMenuButton<String>(
            tooltip: AppStrings.text(state.language, 'language'),
            icon: const Icon(Icons.translate_rounded),
            onSelected: state.setLanguage,
            itemBuilder: (_) => AppStrings.supportedLanguages.entries.map((entry) => PopupMenuItem<String>(
              value: entry.key,
              child: Row(children: [
                if (state.language == entry.key) const Icon(Icons.check_rounded, size: 18) else const SizedBox(width: 18),
                const SizedBox(width: 8),
                Text(entry.value),
              ]),
            )).toList(),
          ),
          IconButton(
            tooltip: AppStrings.text(state.language, 'appearance'),
            onPressed: () => state.setDarkMode(!state.darkMode),
            icon: Icon(state.darkMode ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
          ),
          const SizedBox(width: 4),
        ],
      ),
      drawer: _buildDrawer(context),
      body: SafeArea(child: _page()),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedNavigationIndex,
        onDestinationSelected: (index) {
          switch (index) {
            case 0: _navigate(AppRoute.home); break;
            case 1: _navigate(AppRoute.experience); break;
            case 2: _navigate(AppRoute.portfolio); break;
            case 3: _navigate(AppRoute.more); break;
          }
        },
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home_rounded), label: AppStrings.text(state.language, 'home')),
          NavigationDestination(icon: const Icon(Icons.work_outline_rounded), selectedIcon: const Icon(Icons.work_rounded), label: AppStrings.text(state.language, 'experience')),
          NavigationDestination(icon: const Icon(Icons.grid_view_outlined), selectedIcon: const Icon(Icons.grid_view_rounded), label: AppStrings.text(state.language, 'portfolio')),
          NavigationDestination(icon: const Icon(Icons.menu_rounded), selectedIcon: const Icon(Icons.menu_open_rounded), label: AppStrings.text(state.language, 'more')),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    final state = widget.state;
    final items = <(String, String, IconData)>[
      (AppRoute.home, 'home', Icons.home_outlined),
      (AppRoute.about, 'about', Icons.person_outline_rounded),
      (AppRoute.experience, 'experience', Icons.work_outline_rounded),
      (AppRoute.paklaring, 'paklaring', Icons.verified_user_outlined),
      (AppRoute.education, 'educationTraining', Icons.school_outlined),
      (AppRoute.skills, 'skills', Icons.psychology_alt_outlined),
      (AppRoute.portfolio, 'portfolio', Icons.folder_open_outlined),
      (AppRoute.store, 'store', Icons.storefront_outlined),
      (AppRoute.cv, 'downloadCv', Icons.picture_as_pdf_outlined),
      (AppRoute.contact, 'contact', Icons.alternate_email_rounded),
      (AppRoute.settings, 'settings', Icons.settings_outlined),
    ];
    final currentIndex = items.indexWhere((item) => item.$1 == _route);
    final drawerIndex = currentIndex < 0 ? 0 : currentIndex;
    return NavigationDrawer(
      selectedIndex: drawerIndex,
      onDestinationSelected: (index) {
        Navigator.pop(context);
        _navigate(items[index].$1);
      },
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 26, 20, 20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(15)), child: Icon(Icons.badge_outlined, color: Theme.of(context).colorScheme.primary, size: 28)),
            const SizedBox(height: 12),
            Text('Professional CV', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            Text('Personal Profile & Career Portfolio', style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
        const Divider(indent: 16, endIndent: 16),
        ...items.map((item) => NavigationDrawerDestination(
          icon: Icon(item.$3),
          label: Text(AppStrings.text(state.language, item.$2)),
        )),
      ],
    );
  }
}
