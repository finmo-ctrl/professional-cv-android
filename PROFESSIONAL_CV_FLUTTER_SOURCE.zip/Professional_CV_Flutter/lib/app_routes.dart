class AppRoute {
  AppRoute._();
  static const home = 'home';
  static const about = 'about';
  static const experience = 'experience';
  static const paklaring = 'paklaring';
  static const education = 'education';
  static const skills = 'skills';
  static const portfolio = 'portfolio';
  static const store = 'store';
  static const cv = 'cv';
  static const contact = 'contact';
  static const settings = 'settings';
  static const more = 'more';
}
