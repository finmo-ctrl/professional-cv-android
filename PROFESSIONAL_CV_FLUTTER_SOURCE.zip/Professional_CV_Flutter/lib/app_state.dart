import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  AppState(this._preferences)
      : _language = _preferences.getString('app_language') ?? 'en',
        _darkMode = _preferences.getBool('dark_mode') ?? false;

  final SharedPreferences _preferences;
  String _language;
  bool _darkMode;

  String get language => _language;
  bool get darkMode => _darkMode;

  Future<void> setLanguage(String language) async {
    if (_language == language) return;
    _language = language;
    await _preferences.setString('app_language', language);
    notifyListeners();
  }

  Future<void> setDarkMode(bool enabled) async {
    if (_darkMode == enabled) return;
    _darkMode = enabled;
    await _preferences.setBool('dark_mode', enabled);
    notifyListeners();
  }
}
