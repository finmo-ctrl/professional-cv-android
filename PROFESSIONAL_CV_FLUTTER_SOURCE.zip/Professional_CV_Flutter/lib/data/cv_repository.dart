import 'dart:convert';

import 'package:flutter/services.dart';

class CvRepository {
  CvRepository._(this.data);

  final Map<String, dynamic> data;

  static Future<CvRepository> load() async {
    final raw = await rootBundle.loadString('assets/data/cv_data.json');
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('CV data must be a JSON object.');
    }
    return CvRepository._(decoded);
  }

  Map<String, dynamic> get profile => _map('PROFILE');
  Map<String, dynamic> get education => _map('EDUCATION');
  List<Map<String, dynamic>> get experiences => _maps('EXPERIENCES');
  List<Map<String, dynamic>> get trainings => _maps('TRAININGS');
  List<Map<String, dynamic>> get skills => _maps('SKILLS');
  List<Map<String, dynamic>> get projects => _maps('PROJECTS');
  List<Map<String, dynamic>> get products => _maps('PRODUCTS');
  List<Map<String, dynamic>> get softwareGroups => _maps('SOFTWARE_GROUPS');
  List<String> get designs => _strings('DESIGNS');
  List<String> get gallery => _strings('GALLERY');

  List<String> localizedStringList(String key, String language, List<String> fallback) {
    final raw = data[key];
    if (raw is! Map) return fallback;
    final translated = raw[language];
    if (translated is! List) return fallback;
    return List<String>.generate(fallback.length, (index) {
      if (index >= translated.length) return fallback[index];
      final value = translated[index]?.toString() ?? '';
      if (value.trim().isEmpty || value.toLowerCase() == 'sample') return fallback[index];
      return value;
    });
  }

  Map<String, dynamic> localizedSkill(int index, String language) {
    final raw = data['SKILL_TRANSLATIONS'];
    if (raw is Map) {
      final localized = raw[language];
      if (localized is List && index >= 0 && index < localized.length && localized[index] is Map) {
        return Map<String, dynamic>.from(localized[index] as Map);
      }
    }
    return index >= 0 && index < skills.length ? skills[index] : <String, dynamic>{};
  }

  List<List<String>> productTranslations(String language) {
    final raw = data['PRODUCT_TRANSLATIONS'];
    if (raw is! Map) return const [];
    final value = raw[language] ?? raw['en'];
    if (value is! List) return const [];
    return value.map((item) => item is List
        ? item.map((entry) => entry.toString()).toList()
        : <String>[]).toList();
  }

  Map<String, dynamic> _map(String key) {
    final value = data[key];
    return value is Map<String, dynamic> ? value : <String, dynamic>{};
  }

  List<Map<String, dynamic>> _maps(String key) {
    final value = data[key];
    if (value is! List) return const [];
    return value.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
  }

  List<String> _strings(String key) {
    final value = data[key];
    if (value is! List) return const [];
    return value.map((item) => item.toString()).toList();
  }
}
