import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'app_state.dart';
import 'data/cv_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final preferences = await SharedPreferences.getInstance();
  final appState = AppState(preferences);
  final cvData = await CvRepository.load();
  runApp(ProfessionalCvApp(state: appState, data: cvData));
}
