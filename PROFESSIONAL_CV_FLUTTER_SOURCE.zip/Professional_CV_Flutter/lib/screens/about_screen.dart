import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final profile = data.profile;
    final education = data.education;
    final photo = 'assets/images/reference/profile-sample-01.jpg';
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'about'), subtitle: tx(state, 'professionalSummary')),
      AppPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          SizedBox(width: 88, height: 100, child: AssetPhoto(path: photo, height: 100, borderRadius: 16)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(safeText(profile['name'], 'Name to be completed'), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(safeText(profile['role'], 'Professional Profile'), style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w600)),
          ])),
        ]),
        const SizedBox(height: 18),
        Text(tx(state, 'professionalSummary'), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Text(safeText(profile['about'], tx(state, 'noData')), style: const TextStyle(height: 1.55)),
      ])),
      const SizedBox(height: 14),
      PageHeading(title: tx(state, 'educationBackground')),
      AppPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _FactRow(label: tx(state, 'major'), value: safeText(education['major'], tx(state, 'notProvided'))),
        const Divider(height: 22),
        _FactRow(label: tx(state, 'institution'), value: safeText(education['university'], tx(state, 'notProvided'))),
        const Divider(height: 22),
        _FactRow(label: tx(state, 'gpa'), value: safeText(education['gpa'], tx(state, 'notProvided'))),
      ])),
      const SizedBox(height: 14),
      NoticePanel(text: tx(state, 'sampleNotice')),
    ]);
  }
}

class _FactRow extends StatelessWidget {
  const _FactRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: Theme.of(context).textTheme.labelMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
  ]);
}
