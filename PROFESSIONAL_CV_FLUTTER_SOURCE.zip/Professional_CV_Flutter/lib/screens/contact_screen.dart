import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  Future<void> _open(BuildContext context, Uri uri) async {
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No compatible application was found.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final email = safeText(data.profile['email']);
    final whatsapp = safeText(data.profile['whatsapp']).replaceAll(RegExp(r'[^0-9]'), '');
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'contact'), subtitle: 'Professional enquiries and collaboration'),
      if (email.isNotEmpty)
        Card(child: ListTile(
          leading: const Icon(Icons.email_outlined),
          title: Text(tx(state, 'email')),
          subtitle: Text(email),
          trailing: const Icon(Icons.open_in_new_rounded),
          onTap: () => _open(context, Uri(scheme: 'mailto', path: email)),
        )),
      if (whatsapp.isNotEmpty)
        Card(child: ListTile(
          leading: const Icon(Icons.chat_outlined),
          title: Text(tx(state, 'whatsapp')),
          subtitle: Text(safeText(data.profile['whatsapp'])),
          trailing: const Icon(Icons.open_in_new_rounded),
          onTap: () => _open(context, Uri.parse('https://wa.me/$whatsapp')),
        )),
      if (email.isEmpty && whatsapp.isEmpty)
        const NoticePanel(text: 'Contact details are blank in the source website data. Add your verified email address and WhatsApp number to assets/data/cv_data.json before sharing the app.'),
      const SizedBox(height: 12),
      NoticePanel(text: tx(state, 'contactNote')),
    ]);
  }
}
