import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../services/cv_pdf_builder.dart';
import '../widgets/ui_helpers.dart';

class CvScreen extends StatelessWidget {
  const CvScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  Future<void> _export(BuildContext context, {required bool ats}) async {
    try {
      final bytes = await CvPdfBuilder.build(data, ats: ats);
      await Printing.layoutPdf(
        name: ats ? 'Professional-CV-ATS.pdf' : 'Professional-CV.pdf',
        onLayout: (_) async => bytes,
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Unable to generate the PDF: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'downloadCv'), subtitle: 'Create a PDF copy from the website career data.'),
      _CvOption(
        icon: Icons.fact_check_outlined,
        title: tx(state, 'atsCv'),
        subtitle: 'A clean, text-focused document for applicant tracking systems.',
        onPressed: () => _export(context, ats: true),
        buttonLabel: tx(state, 'generatePdf'),
      ),
      const SizedBox(height: 12),
      _CvOption(
        icon: Icons.description_outlined,
        title: tx(state, 'professionalCv'),
        subtitle: 'A structured professional CV with a longer experience summary.',
        onPressed: () => _export(context, ats: false),
        buttonLabel: tx(state, 'generatePdf'),
      ),
      const SizedBox(height: 14),
      NoticePanel(text: tx(state, 'pdfEnglishNote')),
      const SizedBox(height: 10),
      const NoticePanel(text: 'Review the name, company names, employment periods, education details, and contact information before sending a CV to an employer.'),
    ]);
  }
}

class _CvOption extends StatelessWidget {
  const _CvOption({required this.icon, required this.title, required this.subtitle, required this.onPressed, required this.buttonLabel});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onPressed;
  final String buttonLabel;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(child: Padding(padding: const EdgeInsets.all(17), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(width: 44, height: 44, decoration: BoxDecoration(color: colors.primaryContainer, borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: colors.primary)),
        const SizedBox(width: 12),
        Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
      ]),
      const SizedBox(height: 10),
      Text(subtitle, style: const TextStyle(height: 1.4)),
      const SizedBox(height: 14),
      FilledButton.icon(onPressed: onPressed, icon: const Icon(Icons.picture_as_pdf_outlined), label: Text(buttonLabel)),
    ])));
  }

}
