import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class ExperienceScreen extends StatelessWidget {
  const ExperienceScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'experience'), subtitle: '${data.experiences.length} ${tx(state, 'workRoles').toLowerCase()}'),
      ...data.experiences.asMap().entries.map((entry) {
        final index = entry.key;
        final item = entry.value;
        final title = safeText(item['title'], 'Role ${index + 1}');
        final jobdesk = stringList(item['jobdesk']);
        final achievements = stringList(item['achievement']);
        final workflow = stringList(item['workflow']);
        return Card(
          margin: const EdgeInsets.only(bottom: 11),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: Text('${index + 1}'.padLeft(2, '0'), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800, fontSize: 12)),
            ),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text([
                safeText(item['company'], tx(state, 'notProvided')),
                safeText(item['period'], tx(state, 'notProvided')),
              ].join(' · '), maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
            children: [
              if (safeText(item['summary']).isNotEmpty) ...[
                Text(safeText(item['summary']), style: const TextStyle(height: 1.45)),
                const SizedBox(height: 14),
              ],
              _DetailSection(title: tx(state, 'responsibilities'), items: jobdesk),
              _DetailSection(title: tx(state, 'achievements'), items: achievements),
              _DetailSection(title: tx(state, 'workflow'), items: workflow),
            ],
          ),
        );
      }),
    ]);
  }
}

class _DetailSection extends StatelessWidget {
  const _DetailSection({required this.title, required this.items});
  final String title;
  final List<String> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        BulletItems(items: items),
      ]),
    );
  }
}
