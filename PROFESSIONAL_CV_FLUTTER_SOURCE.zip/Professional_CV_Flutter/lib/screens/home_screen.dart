import 'package:flutter/material.dart';

import '../app_routes.dart';
import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.data, required this.state, required this.onNavigate});
  final CvRepository data;
  final AppState state;
  final ValueChanged<String> onNavigate;

  @override
  Widget build(BuildContext context) {
    final profile = data.profile;
    final colors = Theme.of(context).colorScheme;
    final name = safeText(profile['name'], 'Professional Profile');
    final role = safeText(profile['role'], 'IT Development, Business & Commercial Operations Analyst');
    final about = safeText(profile['about'], tx(state, 'intro'));

    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 28), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [colors.primary, colors.primary.withOpacity(0.82), const Color(0xFF405D7D)],
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.14), borderRadius: BorderRadius.circular(18)),
              child: const Icon(Icons.person_outline_rounded, color: Colors.white, size: 34),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.14), borderRadius: BorderRadius.circular(30)),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.wifi_off_rounded, color: Colors.white, size: 14),
                SizedBox(width: 6),
                Text('OFFLINE READY', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              ]),
            ),
          ]),
          const SizedBox(height: 22),
          Text(tx(state, 'welcome').toUpperCase(), style: TextStyle(color: Colors.white.withOpacity(0.72), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.3)),
          const SizedBox(height: 7),
          Text(name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(role, style: TextStyle(color: Colors.white.withOpacity(0.94), fontSize: 14, height: 1.35, fontWeight: FontWeight.w600)),
          const SizedBox(height: 13),
          Text(about, maxLines: 4, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.45, fontSize: 12)),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: () => onNavigate(AppRoute.about),
            icon: const Icon(Icons.arrow_forward_rounded, size: 17),
            label: Text(tx(state, 'about')),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: BorderSide(color: Colors.white.withOpacity(0.65))),
          ),
        ]),
      ),
      const SizedBox(height: 20),
      PageHeading(title: tx(state, 'careerHighlights'), subtitle: tx(state, 'intro')),
      GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.35,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        children: [
          MetricTile(value: '${data.experiences.length}', label: tx(state, 'workRoles'), icon: Icons.work_outline_rounded),
          MetricTile(value: '${data.trainings.length}', label: tx(state, 'trainingPrograms'), icon: Icons.school_outlined),
          MetricTile(value: '${data.skills.length}', label: tx(state, 'competencyAreas'), icon: Icons.stars_outlined),
          MetricTile(value: '${data.projects.length}', label: tx(state, 'selectedProjects'), icon: Icons.folder_open_outlined),
        ],
      ),
      const SizedBox(height: 22),
      Text(tx(state, 'quickAccess'), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      _QuickCard(icon: Icons.work_history_outlined, title: tx(state, 'experience'), subtitle: '${data.experiences.length} ${tx(state, 'workRoles').toLowerCase()}', onTap: () => onNavigate(AppRoute.experience)),
      _QuickCard(icon: Icons.verified_user_outlined, title: tx(state, 'paklaring'), subtitle: '10 JPG document slots · device storage', onTap: () => onNavigate(AppRoute.paklaring)),
      _QuickCard(icon: Icons.school_outlined, title: tx(state, 'training'), subtitle: '${data.trainings.length} ${tx(state, 'trainingPrograms').toLowerCase()}', onTap: () => onNavigate(AppRoute.education)),
      _QuickCard(icon: Icons.dashboard_customize_outlined, title: tx(state, 'portfolio'), subtitle: '${data.designs.length} design visuals · ${data.projects.length} projects', onTap: () => onNavigate(AppRoute.portfolio)),
      const SizedBox(height: 10),
      NoticePanel(text: tx(state, 'sampleNotice')),
    ]);
  }
}

class _QuickCard extends StatelessWidget {
  const _QuickCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        leading: Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(color: colors.primaryContainer, borderRadius: BorderRadius.circular(13)),
          child: Icon(icon, color: colors.primary),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}
