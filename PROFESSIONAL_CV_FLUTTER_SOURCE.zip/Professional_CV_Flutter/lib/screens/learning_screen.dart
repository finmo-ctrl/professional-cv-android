import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class LearningScreen extends StatelessWidget {
  const LearningScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final education = data.education;
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'education'), subtitle: tx(state, 'educationBackground')),
      AppPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(safeText(education['major'], tx(state, 'notProvided')), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(safeText(education['university'], tx(state, 'notProvided'))),
        if (safeText(education['gpa']).isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('${tx(state, 'gpa')}: ${education['gpa']}'),
        ],
      ])),
      const SizedBox(height: 22),
      PageHeading(title: tx(state, 'training'), subtitle: '${data.trainings.length} ${tx(state, 'trainingPrograms').toLowerCase()}'),
      ...data.trainings.asMap().entries.map((entry) {
        final item = entry.value;
        final modules = stringList(item['modules']);
        final workflow = stringList(item['workflow']);
        final achievements = stringList(item['achievements']);
        final outcomeValue = item['outcome'];
        final outcomes = outcomeValue is List
            ? stringList(outcomeValue)
            : (safeText(outcomeValue).isNotEmpty ? <String>[safeText(outcomeValue)] : <String>[]);
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ExpansionTile(
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: Icon(Icons.school_outlined, color: Theme.of(context).colorScheme.primary),
            ),
            title: Text(safeText(item['title'], 'Training ${entry.key + 1}'), style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text([
              safeText(item['provider'], tx(state, 'notProvided')),
              safeText(item['period'], tx(state, 'notProvided')),
            ].join(' · ')),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              if (safeText(item['description']).isNotEmpty) Text(safeText(item['description']), style: const TextStyle(height: 1.45)),
              _TrainingSection(title: tx(state, 'modules'), items: modules),
              _TrainingSection(title: tx(state, 'workflow'), items: workflow),
              _TrainingSection(title: tx(state, 'outcomes'), items: outcomes),
              _TrainingSection(title: tx(state, 'achievements'), items: achievements),
            ],
          ),
        );
      }),
    ]);
  }
}

class _TrainingSection extends StatelessWidget {
  const _TrainingSection({required this.title, required this.items});
  final String title;
  final List<String> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        BulletItems(items: items),
      ]),
    );
  }
}
