import 'package:flutter/material.dart';

import '../app_routes.dart';
import '../app_state.dart';
import '../widgets/ui_helpers.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key, required this.state, required this.onNavigate});
  final AppState state;
  final ValueChanged<String> onNavigate;

  @override
  Widget build(BuildContext context) {
    final items = <(String, IconData, String)>[
      (AppRoute.about, Icons.person_outline_rounded, 'about'),
      (AppRoute.paklaring, Icons.verified_user_outlined, 'paklaring'),
      (AppRoute.education, Icons.school_outlined, 'educationTraining'),
      (AppRoute.skills, Icons.psychology_alt_outlined, 'skills'),
      (AppRoute.store, Icons.storefront_outlined, 'store'),
      (AppRoute.cv, Icons.picture_as_pdf_outlined, 'downloadCv'),
      (AppRoute.contact, Icons.alternate_email_rounded, 'contact'),
      (AppRoute.settings, Icons.settings_outlined, 'settings'),
    ];
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'quickAccess')),
      ...items.map((item) => Card(
        margin: const EdgeInsets.only(bottom: 9),
        child: ListTile(
          leading: Icon(item.$2),
          title: Text(tx(state, item.$3), style: const TextStyle(fontWeight: FontWeight.w700)),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => onNavigate(item.$1),
        ),
      )),
    ]);
  }
}
