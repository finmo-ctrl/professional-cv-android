import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../app_state.dart';
import '../services/paklaring_repository.dart';
import '../widgets/ui_helpers.dart';

class PaklaringScreen extends StatefulWidget {
  const PaklaringScreen({super.key, required this.state});
  final AppState state;

  @override
  State<PaklaringScreen> createState() => _PaklaringScreenState();
}

class _PaklaringScreenState extends State<PaklaringScreen> {
  final PaklaringRepository _repository = PaklaringRepository.instance;
  late Future<List<EmploymentDocument>> _documentsFuture;

  @override
  void initState() {
    super.initState();
    _documentsFuture = _repository.getAll();
  }

  void _reload() {
    setState(() => _documentsFuture = _repository.getAll());
  }

  Future<void> _addDocument(int slot, EmploymentDocument? current) async {
    final titleController = TextEditingController(text: current?.title ?? 'Employment Certificate $slot');
    final companyController = TextEditingController(text: current?.company ?? '');
    final periodController = TextEditingController(text: current?.period ?? '');
    final details = await showDialog<Map<String, String>>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(tx(widget.state, 'documentSlot') + ' $slot'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleController, decoration: InputDecoration(labelText: tx(widget.state, 'documentTitle'))),
          TextField(controller: companyController, decoration: InputDecoration(labelText: tx(widget.state, 'company'))),
          TextField(controller: periodController, decoration: InputDecoration(labelText: tx(widget.state, 'period'))),
          const SizedBox(height: 10),
          Text(tx(widget.state, 'jpgOnly'), style: Theme.of(dialogContext).textTheme.bodySmall),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(tx(widget.state, 'cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, {
            'title': titleController.text.trim(),
            'company': companyController.text.trim(),
            'period': periodController.text.trim(),
          }), child: Text(tx(widget.state, 'save'))),
        ],
      ),
    );
    titleController.dispose();
    companyController.dispose();
    periodController.dispose();
    if (details == null || !mounted) return;

    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['jpg'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final selected = result.files.single;
      if (selected.extension?.toLowerCase() != 'jpg') {
        _showMessage(tx(widget.state, 'jpgOnly'));
        return;
      }
      final bytes = selected.bytes ?? (selected.path != null ? await File(selected.path!).readAsBytes() : null);
      if (bytes == null) {
        _showMessage('The selected image could not be read. Please choose another JPG file.');
        return;
      }
      final savedPath = await _repository.storeJpg(slot, bytes);
      await _repository.save(EmploymentDocument(
        slot: slot,
        title: details['title']?.isNotEmpty == true ? details['title']! : 'Employment Certificate $slot',
        company: details['company'] ?? '',
        period: details['period'] ?? '',
        filePath: savedPath,
      ));
      _reload();
      _showMessage('Document saved on this device.');
    } on FormatException {
      _showMessage(tx(widget.state, 'jpgOnly'));
    } catch (error) {
      _showMessage('Unable to save this document: $error');
    }
  }

  Future<void> _previewDocument(EmploymentDocument document) async {
    final file = File(document.filePath);
    if (!await file.exists() || !mounted) {
      _showMessage('The saved JPG could not be found on this device.');
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: EdgeInsets.zero,
        child: SafeArea(child: Scaffold(
          appBar: AppBar(
            title: Text(document.title),
            leading: IconButton(
              icon: const Icon(Icons.close_rounded),
              onPressed: () => Navigator.pop(dialogContext),
            ),
          ),
          body: InteractiveViewer(
            minScale: 0.5,
            maxScale: 5,
            child: Center(child: Image.file(file, fit: BoxFit.contain)),
          ),
        )),
      ),
    );
  }

  Future<void> _removeDocument(int slot) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(tx(widget.state, 'removeDocument')),
        content: Text(tx(widget.state, 'deleteConfirm')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(tx(widget.state, 'cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(tx(widget.state, 'removeDocument'))),
        ],
      ),
    );
    if (confirmed != true) return;
    await _repository.remove(slot);
    _reload();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final language = widget.state;
    return FutureBuilder<List<EmploymentDocument>>(
      future: _documentsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Local document storage could not be opened: ${snapshot.error}')));
        }
        final documents = <int, EmploymentDocument>{
          for (final item in snapshot.data ?? <EmploymentDocument>[]) item.slot: item,
        };
        return ListView(padding: const EdgeInsets.all(16), children: [
          PageHeading(title: tx(language, 'paklaring'), subtitle: '10 private local document slots'),
          NoticePanel(text: tx(language, 'documentPrivacy'), icon: Icons.lock_outline_rounded),
          const SizedBox(height: 10),
          NoticePanel(text: tx(language, 'jpgOnly'), icon: Icons.image_outlined),
          const SizedBox(height: 14),
          for (var slot = 1; slot <= 10; slot++)
            _DocumentCard(
              slot: slot,
              document: documents[slot],
              state: language,
              onAdd: () => _addDocument(slot, documents[slot]),
              onRemove: documents.containsKey(slot) ? () => _removeDocument(slot) : null,
              onPreview: documents[slot] != null ? () => _previewDocument(documents[slot]!) : null,
            ),
        ]);
      },
    );
  }
}

class _DocumentCard extends StatelessWidget {
  const _DocumentCard({required this.slot, required this.document, required this.state, required this.onAdd, this.onRemove, this.onPreview});
  final int slot;
  final EmploymentDocument? document;
  final AppState state;
  final VoidCallback onAdd;
  final VoidCallback? onRemove;
  final VoidCallback? onPreview;

  @override
  Widget build(BuildContext context) {
    final hasFile = document != null && File(document!.filePath).existsSync();
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          GestureDetector(
            onTap: hasFile ? onPreview : null,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(11),
              child: hasFile
                  ? Image.file(File(document!.filePath), width: 68, height: 82, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _placeholder(colors))
                  : _placeholder(colors),
            ),
          ),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${tx(state, 'slot')} ${slot.toString().padLeft(2, '0')}', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: colors.primary, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(document?.title ?? tx(state, 'noDocument'), style: const TextStyle(fontWeight: FontWeight.w700)),
            if (document != null && document!.company.isNotEmpty) Text(document!.company, style: Theme.of(context).textTheme.bodySmall),
            if (document != null && document!.period.isNotEmpty) Text(document!.period, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 7),
            Text(hasFile ? 'JPG · Stored locally' : tx(state, 'noDocument'), style: Theme.of(context).textTheme.labelSmall?.copyWith(color: colors.onSurfaceVariant)),
          ])),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'edit') onAdd();
              if (value == 'remove') onRemove?.call();
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'edit', child: Text(document == null ? tx(state, 'addDocument') : tx(state, 'replaceDocument'))),
              if (document != null) PopupMenuItem(value: 'remove', child: Text(tx(state, 'removeDocument'))),
            ],
            icon: const Icon(Icons.more_vert_rounded),
          ),
        ]),
      ),
    );
  }

  Widget _placeholder(ColorScheme colors) => Container(
    width: 68,
    height: 82,
    color: colors.surfaceVariant,
    alignment: Alignment.center,
    child: Icon(Icons.description_outlined, color: colors.primary, size: 30),
  );
}
