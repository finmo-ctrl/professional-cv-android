import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: PageHeading(title: tx(state, 'portfolio'), subtitle: '${data.designs.length} design visuals · ${data.projects.length} digital projects'),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: TabBar(tabs: [
            Tab(text: tx(state, 'portfolioDesigns')),
            Tab(text: tx(state, 'portfolioProjects')),
            Tab(text: tx(state, 'portfolioGallery')),
          ]),
        ),
        Expanded(child: TabBarView(children: [
          _ImageGrid(
            titles: data.localizedStringList('DESIGN_TRANSLATIONS', state.language, data.designs),
            count: data.designs.length,
            pathFor: (index) => 'assets/images/designs/design-${(index + 1).toString().padLeft(2, '0')}.jpg',
          ),
          _ProjectList(data: data),
          _ImageGrid(
            titles: data.localizedStringList('GALLERY_TRANSLATIONS', state.language, data.gallery),
            count: data.gallery.length,
            pathFor: (index) => 'assets/images/gallery/memory-${(index + 1).toString().padLeft(2, '0')}.jpg',
          ),
        ])),
      ]),
    );
  }
}

class _ImageGrid extends StatelessWidget {
  const _ImageGrid({required this.titles, required this.count, required this.pathFor});
  final List<String> titles;
  final int count;
  final String Function(int index) pathFor;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(14),
      itemCount: count,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.84,
      ),
      itemBuilder: (context, index) {
        final path = pathFor(index);
        final title = index < titles.length ? titles[index] : 'Portfolio image ${index + 1}';
        return InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: () => showDialog<void>(
            context: context,
            builder: (dialogContext) => Dialog(
              child: Padding(padding: const EdgeInsets.all(12), child: Column(mainAxisSize: MainAxisSize.min, children: [
                ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset(path, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, size: 60))),
                const SizedBox(height: 10),
                Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Close'))),
              ])),
            ),
          ),
          child: Card(
            clipBehavior: Clip.antiAlias,
            margin: EdgeInsets.zero,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Image.asset(path, width: double.infinity, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: Theme.of(context).colorScheme.surfaceVariant, child: const Center(child: Icon(Icons.image_not_supported_outlined))))),
              Padding(padding: const EdgeInsets.all(10), child: Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12))),
            ]),
          ),
        );
      },
    );
  }
}

class _ProjectList extends StatelessWidget {
  const _ProjectList({required this.data});
  final CvRepository data;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(14),
      itemCount: data.projects.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final project = data.projects[index];
        final image = 'assets/images/projects/project-${(index + 1).toString().padLeft(2, '0')}.jpg';
        return Card(
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            AssetPhoto(path: image, height: 160, borderRadius: 0),
            Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(safeText(project['category']), style: Theme.of(context).textTheme.labelSmall?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(safeText(project['title']), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 7),
              Text(safeText(project['description']), style: const TextStyle(height: 1.4)),
              const SizedBox(height: 9),
              Text(safeText(project['tools']), style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 4),
              Text(safeText(project['year'], 'Conceptual prototype'), style: Theme.of(context).textTheme.labelSmall),
            ])),
          ]),
        );
      },
    );
  }
}
