import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../services/firebase_rest_service.dart';
import '../widgets/ui_helpers.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final isFirebaseConfigured = FirebaseRestService.databaseUrl.trim().isNotEmpty;
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'settings')),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(tx(state, 'language'), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Text(tx(state, 'defaultLanguage'), style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: state.language,
          decoration: const InputDecoration(border: OutlineInputBorder(), prefixIcon: Icon(Icons.translate_rounded)),
          items: AppStrings.supportedLanguages.entries.map((entry) => DropdownMenuItem(
            value: entry.key,
            child: Text(entry.value),
          )).toList(),
          onChanged: (value) {
            if (value != null) state.setLanguage(value);
          },
        ),
      ]))),
      const SizedBox(height: 12),
      Card(child: SwitchListTile.adaptive(
        value: state.darkMode,
        onChanged: state.setDarkMode,
        secondary: Icon(state.darkMode ? Icons.dark_mode_outlined : Icons.light_mode_outlined),
        title: Text(tx(state, 'appearance'), style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(state.darkMode ? tx(state, 'darkMode') : tx(state, 'lightMode')),
      )),
      const SizedBox(height: 12),
      Card(child: ListTile(
        leading: const Icon(Icons.cloud_outlined),
        title: Text(tx(state, 'cloudSync'), style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(isFirebaseConfigured ? 'Firebase database URL configured.' : tx(state, 'cloudNotConfigured')),
        trailing: Icon(isFirebaseConfigured ? Icons.check_circle_outline : Icons.info_outline),
      )),
      const SizedBox(height: 12),
      const NoticePanel(text: 'The app starts in English on a fresh installation. Your manually selected language and appearance are saved on this device.'),
      const SizedBox(height: 12),
      const NoticePanel(text: 'Employment certificate JPG files are stored in the app-private document folder. They are intentionally excluded from Firebase synchronisation.'),
    ]);
  }
}
