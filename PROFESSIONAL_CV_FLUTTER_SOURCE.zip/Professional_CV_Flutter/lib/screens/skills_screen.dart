import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class SkillsScreen extends StatelessWidget {
  const SkillsScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'skills'), subtitle: tx(state, 'softwareTools')),
      ...List.generate(data.skills.length, (index) {
        final skill = data.localizedSkill(index, state.language);
        final tags = stringList(skill['tags']);
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(safeText(skill['title']), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 7),
            Text(safeText(skill['description']), style: const TextStyle(height: 1.45)),
            if (tags.isNotEmpty) ...[
              const SizedBox(height: 12),
              Wrap(spacing: 7, runSpacing: 7, children: tags.map((tag) => Chip(
                label: Text(tag, style: const TextStyle(fontSize: 11)),
                visualDensity: VisualDensity.compact,
                side: BorderSide.none,
              )).toList()),
            ],
          ])),
        );
      }),
      const SizedBox(height: 10),
      PageHeading(title: tx(state, 'softwareTools')),
      ...data.softwareGroups.map((group) {
        final items = stringList(group['items']);
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(safeText(group['title']), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: items.map((item) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                borderRadius: BorderRadius.circular(9),
              ),
              child: Text(item, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            )).toList()),
          ])),
        );
      }),
    ]);
  }
}
