import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/cv_repository.dart';
import '../widgets/ui_helpers.dart';

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key, required this.data, required this.state});
  final CvRepository data;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final translations = data.productTranslations(state.language);
    return ListView(padding: const EdgeInsets.all(16), children: [
      PageHeading(title: tx(state, 'store'), subtitle: '${data.products.length} product and service categories'),
      AppPanel(padding: EdgeInsets.zero, child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Image.asset('assets/images/toko-banner.jpg', height: 145, width: double.infinity, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(height: 145, color: Theme.of(context).colorScheme.primaryContainer, alignment: Alignment.center, child: const Icon(Icons.storefront_outlined, size: 45))),
      )),
      const SizedBox(height: 12),
      NoticePanel(text: tx(state, 'storeNotice')),
      const SizedBox(height: 14),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: data.products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.76,
          crossAxisSpacing: 11,
          mainAxisSpacing: 11,
        ),
        itemBuilder: (context, index) {
          final product = data.products[index];
          final translated = index < translations.length ? translations[index] : const <String>[];
          final title = translated.isNotEmpty ? translated[0] : safeText(product['title']);
          final description = translated.length > 1 ? translated[1] : safeText(product['desc']);
          final image = 'assets/images/products/product-${(index + 1).toString().padLeft(2, '0')}.jpg';
          return Card(
            clipBehavior: Clip.antiAlias,
            margin: EdgeInsets.zero,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Image.asset(image, width: double.infinity, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: Theme.of(context).colorScheme.surfaceVariant, child: const Center(child: Icon(Icons.inventory_2_outlined))))),
              Padding(padding: const EdgeInsets.fromLTRB(10, 9, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                const SizedBox(height: 4),
                Text(description, maxLines: 3, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.3)),
              ])),
            ]),
          );
        },
      ),
    ]);
  }
}
