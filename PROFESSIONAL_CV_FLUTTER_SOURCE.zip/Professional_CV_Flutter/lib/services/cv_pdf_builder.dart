import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../data/cv_repository.dart';

class CvPdfBuilder {
  static Future<Uint8List> build(CvRepository repository, {required bool ats}) async {
    final data = repository;
    final profile = data.profile;
    final education = data.education;
    final document = pw.Document();

    final name = _value(profile['name'], 'Name to be completed');
    final role = _value(profile['role'], 'Professional Profile');
    final about = _value(profile['about'], 'Professional summary to be completed.');
    final sections = <pw.Widget>[
      pw.Text(name, style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 4),
      pw.Text(role, style: const pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
      if ((profile['email']?.toString().trim().isNotEmpty ?? false))
        pw.Text(profile['email'].toString(), style: const pw.TextStyle(fontSize: 9)),
      pw.SizedBox(height: 14),
      _heading('Professional Summary'),
      pw.Paragraph(text: about),
      _heading('Professional Experience'),
    ];

    for (final experience in data.experiences) {
      final title = _value(experience['title'], 'Role');
      final company = _value(experience['company'], 'Company to be verified');
      final period = _value(experience['period'], 'Period to be verified');
      sections.add(pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 8),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Expanded(child: pw.Text(title, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
            pw.SizedBox(width: 8),
            pw.Text(period, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
          ]),
          pw.Text(company, style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
          pw.SizedBox(height: 2),
          pw.Text(_value(experience['summary'], ''), style: const pw.TextStyle(fontSize: 9)),
          for (final item in _strings(experience['jobdesk']).take(ats ? 5 : 8))
            pw.Padding(
              padding: const pw.EdgeInsets.only(left: 8, top: 2),
              child: pw.Text('- $item', style: const pw.TextStyle(fontSize: 8.5)),
            ),
        ]),
      ));
    }

    sections.addAll([
      _heading('Education'),
      pw.Paragraph(text: '${_value(education['major'], 'Major to be completed')} · ${_value(education['university'], 'Institution to be completed')}'),
    ]);

    if (data.trainings.isNotEmpty) {
      sections.add(_heading('Training & Professional Development'));
      for (final training in data.trainings) {
        sections.add(pw.Container(
          margin: const pw.EdgeInsets.only(bottom: 7),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text(_value(training['title'], 'Training programme'), style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9.5)),
            pw.Text('${_value(training['provider'], 'Provider to be verified')} · ${_value(training['period'], 'Period to be verified')}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
            pw.SizedBox(height: 2),
            pw.Text(_value(training['description'], ''), style: const pw.TextStyle(fontSize: 8.5)),
          ]),
        ));
      }
    }

    sections.add(_heading('Core Competencies'));
    for (final skill in data.skills) {
      sections.add(pw.Paragraph(text: '${_value(skill['title'], '')}: ${_value(skill['description'], '')}'));
    }
    if (data.softwareGroups.isNotEmpty) {
      sections.add(_heading('Software & Tools Proficiency'));
      for (final group in data.softwareGroups) {
        final items = _strings(group['items']);
        sections.add(pw.Paragraph(text: '${_value(group['title'], '')}: ${items.join(', ')}'));
      }
    }

    document.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(34),
      build: (_) => sections,
      footer: (context) => pw.Container(
        alignment: pw.Alignment.centerRight,
        margin: const pw.EdgeInsets.only(top: 8),
        child: pw.Text('Page ${context.pageNumber} of ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
      ),
    ));
    return document.save();
  }

  static pw.Widget _heading(String value) => pw.Padding(
        padding: const pw.EdgeInsets.only(top: 10, bottom: 4),
        child: pw.Text(value, style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
      );

  static String _value(dynamic value, String fallback) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? fallback : text;
  }

  static List<String> _strings(dynamic value) {
    if (value is! List) return const [];
    return value.map((item) => item.toString()).toList();
  }
}
