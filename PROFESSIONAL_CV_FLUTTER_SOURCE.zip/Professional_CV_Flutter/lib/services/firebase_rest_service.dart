import 'dart:convert';

import 'package:http/http.dart' as http;

/// Optional Firebase Realtime Database REST client.
/// Keep the database rules restrictive. Never embed service-account keys or
/// private authentication credentials in an APK.
class FirebaseRestService {
  FirebaseRestService({http.Client? client}) : _client = client ?? http.Client();

  static const String databaseUrl = String.fromEnvironment(
    'FIREBASE_DATABASE_URL',
    defaultValue: '',
  );

  final http.Client _client;

  bool get isConfigured => databaseUrl.trim().isNotEmpty;

  Uri _uri(String path, {String? authToken}) {
    final base = databaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) throw StateError('Firebase database URL is not configured.');
    final cleanPath = path.replaceAll(RegExp(r'^/+|/+$'), '');
    final query = <String, String>{};
    if (authToken != null && authToken.isNotEmpty) query['auth'] = authToken;
    return Uri.parse('$base/$cleanPath.json').replace(queryParameters: query.isEmpty ? null : query);
  }

  Future<dynamic> read(String path, {String? authToken}) async {
    final response = await _client.get(_uri(path, authToken: authToken));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Firebase read failed (${response.statusCode}).');
    }
    return jsonDecode(response.body);
  }

  Future<void> write(String path, Object? value, {String? authToken}) async {
    final response = await _client.put(
      _uri(path, authToken: authToken),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode(value),
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Firebase write failed (${response.statusCode}).');
    }
  }

  void close() => _client.close();
}
