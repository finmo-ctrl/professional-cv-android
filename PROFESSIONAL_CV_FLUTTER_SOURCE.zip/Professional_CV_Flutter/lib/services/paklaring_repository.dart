import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class EmploymentDocument {
  const EmploymentDocument({
    required this.slot,
    required this.title,
    required this.company,
    required this.period,
    required this.filePath,
  });

  final int slot;
  final String title;
  final String company;
  final String period;
  final String filePath;

  factory EmploymentDocument.fromMap(Map<String, Object?> map) {
    return EmploymentDocument(
      slot: (map['slot'] as num).toInt(),
      title: map['title']?.toString() ?? '',
      company: map['company']?.toString() ?? '',
      period: map['period']?.toString() ?? '',
      filePath: map['file_path']?.toString() ?? '',
    );
  }
}

class PaklaringRepository {
  PaklaringRepository._();
  static final PaklaringRepository instance = PaklaringRepository._();

  Database? _database;

  Future<Database> get _db async {
    if (_database != null) return _database!;
    final dbPath = await getDatabasesPath();
    _database = await openDatabase(
      p.join(dbPath, 'professional_cv_local.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE employment_documents (
            slot INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            company TEXT NOT NULL,
            period TEXT NOT NULL,
            file_path TEXT NOT NULL,
            updated_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<List<EmploymentDocument>> getAll() async {
    final db = await _db;
    final rows = await db.query('employment_documents', orderBy: 'slot ASC');
    return rows.map(EmploymentDocument.fromMap).toList();
  }

  Future<void> save(EmploymentDocument document) async {
    final db = await _db;
    await db.insert(
      'employment_documents',
      {
        'slot': document.slot,
        'title': document.title,
        'company': document.company,
        'period': document.period,
        'file_path': document.filePath,
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> remove(int slot) async {
    final db = await _db;
    final rows = await db.query(
      'employment_documents',
      columns: ['file_path'],
      where: 'slot = ?',
      whereArgs: [slot],
      limit: 1,
    );
    if (rows.isNotEmpty) {
      final path = rows.first['file_path']?.toString() ?? '';
      if (path.isNotEmpty) {
        final file = File(path);
        if (await file.exists()) await file.delete();
      }
    }
    await db.delete('employment_documents', where: 'slot = ?', whereArgs: [slot]);
  }

  Future<String> storeJpg(int slot, List<int> bytes) async {
    if (!_isJpeg(bytes)) {
      throw const FormatException('The selected file is not a valid JPEG image.');
    }
    final appDirectory = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(appDirectory.path, 'employment_certificates'));
    if (!await folder.exists()) await folder.create(recursive: true);
    final target = File(p.join(folder.path, 'employment-${slot.toString().padLeft(2, '0')}.jpg'));
    await target.writeAsBytes(bytes, flush: true);
    return target.path;
  }

  bool _isJpeg(List<int> bytes) {
    return bytes.length >= 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF;
  }
}
