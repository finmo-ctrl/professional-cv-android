#!/usr/bin/env python3
"""Add the Android internet permission and production app label after flutter create."""
from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit('AndroidManifest.xml was not generated. Run flutter create first.')
text = manifest.read_text(encoding='utf-8')
permission = '<uses-permission android:name="android.permission.INTERNET" />'
if 'android.permission.INTERNET' not in text:
    text = re.sub(r'(<manifest\b[^>]*>)', r'\1\n    ' + permission, text, count=1)
text = re.sub(r'android:label="[^"]*"', 'android:label="Professional CV"', text, count=1)
manifest.write_text(text, encoding='utf-8')
print('Android manifest prepared: internet permission enabled; app label set to Professional CV.')
