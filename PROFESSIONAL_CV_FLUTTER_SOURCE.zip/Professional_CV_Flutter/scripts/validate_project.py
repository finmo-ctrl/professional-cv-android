#!/usr/bin/env python3
"""Lightweight pre-build checks for the Professional CV Flutter project."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "assets" / "data" / "cv_data.json"
IMAGE_ROOT = ROOT / "assets" / "images"
EXPECTED_COUNTS = {
    "EXPERIENCES": 10,
    "TRAININGS": 4,
    "SKILLS": 6,
    "SOFTWARE_GROUPS": 5,
    "DESIGNS": 40,
    "PROJECTS": 3,
    "GALLERY": 50,
    "PRODUCTS": 20,
}
EXPECTED_LANGUAGES = {"en", "id", "ja", "ko", "zh", "de", "th"}


def fail(message: str) -> None:
    print(f"VALIDATION ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    if not DATA_FILE.is_file():
        fail("assets/data/cv_data.json is missing")
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        fail(f"CV JSON is invalid: {exc}")

    for key, expected in EXPECTED_COUNTS.items():
        actual = len(data.get(key, []))
        if actual != expected:
            fail(f"{key}: expected {expected} records, found {actual}")

    if not IMAGE_ROOT.is_dir():
        fail("assets/images directory is missing")
    image_files = [path for path in IMAGE_ROOT.rglob("*") if path.is_file()]
    non_jpg = [path.relative_to(ROOT).as_posix() for path in image_files if path.suffix.lower() != ".jpg"]
    if non_jpg:
        fail("non-.jpg image assets found: " + ", ".join(non_jpg[:10]))

    invalid_jpeg = []
    for path in image_files:
        try:
            with path.open("rb") as stream:
                header = stream.read(3)
                stream.seek(-2, 2)
                trailer = stream.read(2)
        except OSError as exc:
            invalid_jpeg.append(f"{path.relative_to(ROOT)} ({exc})")
            continue
        if header != b"\xff\xd8\xff" or trailer != b"\xff\xd9":
            invalid_jpeg.append(str(path.relative_to(ROOT)))
    if invalid_jpeg:
        fail("files with .jpg extension but invalid JPEG signatures: " + ", ".join(invalid_jpeg[:10]))

    # Verify local image references authored in Dart and stored in the imported JSON.
    references: set[str] = set()
    for dart_file in (ROOT / "lib").rglob("*.dart"):
        text = dart_file.read_text(encoding="utf-8")
        references.update(re.findall(r"assets/images/[A-Za-z0-9_./ -]+\.jpg", text))
        if re.search(r"assets/images/[^'\"]+\.(?:png|jpeg|webp)", text, re.IGNORECASE):
            fail(f"non-JPG image reference found in {dart_file.relative_to(ROOT)}")
    references.update(re.findall(r"assets/images/[A-Za-z0-9_./ -]+\.jpg", json.dumps(data)))
    missing = sorted(ref for ref in references if not (ROOT / ref).is_file())
    if missing:
        fail("referenced image assets are missing: " + ", ".join(missing[:20]))

    strings_file = ROOT / "lib" / "l10n" / "app_strings.dart"
    strings_text = strings_file.read_text(encoding="utf-8")
    found_languages = set(re.findall(r"^\s*'([a-z]{2})':\s*\{", strings_text, re.MULTILINE))
    if found_languages != EXPECTED_LANGUAGES:
        fail(f"language list mismatch: expected {sorted(EXPECTED_LANGUAGES)}, found {sorted(found_languages)}")
    if "_language = _preferences.getString('app_language') ?? 'en'" not in (ROOT / "lib" / "app_state.dart").read_text(encoding="utf-8"):
        fail("English is not configured as the first-install language")

    print("Professional CV source validation: PASS")
    print(f"- Imported website records: {EXPECTED_COUNTS}")
    print(f"- Local image files: {len(image_files)} actual JPG files")
    print(f"- Local image references checked: {len(references)}")
    print(f"- Supported manual languages: {', '.join(sorted(EXPECTED_LANGUAGES))}")
    print("- First-install language: English")


if __name__ == "__main__":
    main()
