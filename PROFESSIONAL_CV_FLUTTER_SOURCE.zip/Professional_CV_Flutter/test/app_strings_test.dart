import 'package:flutter_test/flutter_test.dart';
import 'package:professional_cv/l10n/app_strings.dart';

void main() {
  group('Application localisation', () {
    test('supports the seven agreed languages', () {
      expect(AppStrings.supportedLanguages.keys.toList(), ['en', 'id', 'ja', 'ko', 'zh', 'de', 'th']);
    });

    test('English is the application fallback', () {
      expect(AppStrings.text('unknown', 'home'), 'Home');
      expect(AppStrings.text('en', 'appName'), 'Professional CV');
    });

    test('navigation labels are available for all supported languages', () {
      const keys = ['home', 'about', 'experience', 'paklaring', 'education', 'training', 'skills', 'portfolio', 'gallery', 'store', 'downloadCv', 'contact', 'settings'];
      for (final language in AppStrings.supportedLanguages.keys) {
        for (final key in keys) {
          expect(AppStrings.text(language, key).trim(), isNotEmpty, reason: '$key is empty for $language');
        }
      }
    });
  });
}
