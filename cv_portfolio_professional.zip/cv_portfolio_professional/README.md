# Professional CV, Portfolio & Toko Berkah Website

Responsive CV and portfolio website built with HTML5, CSS3, vanilla JavaScript, and PHP session-based authentication. The project includes CV print layouts, work-experience and training details, software skills, JPG-only design and gallery collections, a 20-category Toko Berkah catalogue, five interface languages, and an optional contact form delivery endpoint.

## What has been revised

- **Product catalogue:** 20 product/service categories, each with its own JPG cover at exactly **640 × 460 px**. Product cards use `.jpg` paths and a valid JPG fallback.
- **Software icons:** the requested software familiarity groups are now displayed using offline-safe monogram badges. They do not depend on remote icon CDNs, so blocked external requests will not make the icons disappear.
- **Design & Portfolio:** 30 design images, JPG format only (`design-01.jpg` through `design-30.jpg`).
- **Gallery:** 45 JPG visual slots (`memory-01.jpg` through `memory-45.jpg`). These are illustrative sample visuals, not claims of real personal events; replace them with photographs you own or have permission to publish.
- **Toko Berkah:** 20 JPG category covers with professional English product descriptions and localized names/descriptions for Indonesian, English, Korean, Japanese, and Simplified Chinese.
- **Language selector:** interface labels, section headings, form labels, software group labels, skills, store catalogue, and portfolio/gallery captions respond to the selected language. Detailed employment and training bullets remain authored in English in this edition and should be translated in the content data before describing the entire CV body as fully localized.
- **Contact form:** includes a Google Apps Script endpoint that can log each message to Google Sheets and send it to the configured Gmail address. This must be configured and deployed before email delivery will work.

## Run locally

## Login and privacy protection

Windows 7 compatibility build: designed to run with PHP 7.4.x (for example, a legacy XAMPP package that includes PHP 7.4.33) and Apache. PHP 7.4 is end-of-life, so use this legacy setup for local/offline viewing only; do not expose it directly to the public internet. A currently supported PHP version is strongly preferred for public hosting. This project must be run through a PHP-enabled web server. Do **not** open the page as a local `file://` document. The public `index.html` only redirects to the login screen; the actual CV is in `portfolio.php` and checks a server-side session.

- Login page: `index.php`
- Protected portfolio: `portfolio.php`
- Logout: `logout.php` (POST + CSRF token)
- Credentials: `config/auth.php` (password is stored as a PHP password hash)
- CV data: `assets/js/config.php`, returned only to authenticated sessions
- Profile, design, gallery, and certificate JPGs are kept in `private_media/` and served through `media.php` after login.
- Login attempts are limited to five failures per session, followed by a 15-minute lockout. Sessions expire after 30 minutes of inactivity.
- Contact submission endpoint also requires an authenticated session.

### Initial login

- Username: `admin`
- Temporary password: `CVakses2026!`

Change the temporary password immediately before using the site with real personal information.

### Change username and password

1. Open `config/auth.php` and change the `username` value.
2. Generate a password hash from your new password on a computer with PHP installed:

   ```bash
   php -r "echo password_hash('YourNewStrongPassword', PASSWORD_DEFAULT), PHP_EOL;"
   ```

3. Replace the `password_hash` value in `config/auth.php` with the generated hash. Never put the plain-text password in the source code.
4. Use HTTPS in production. The included `.htaccess` rules are for Apache. If deploying to Nginx, configure equivalent rules to deny direct web access to `private_media/`, `config/`, and `includes/` while allowing `media.php` to read protected images.

### Run on Windows 7 with XAMPP (recommended for this legacy build)

1. Install a trusted XAMPP package that includes PHP 7.4.x and Apache. PHP 7.4 is no longer security-supported; keep this installation local and offline.
2. Copy the complete `cv_portfolio_professional` folder into `C:\xampp\htdocs\`.
3. Open the XAMPP Control Panel and start **Apache**. MySQL is not required for the login.
4. Open `http://localhost/cv_portfolio_professional/` in the browser. The login page appears first.
5. Sign in with the temporary credentials above, then change the password hash in `config/auth.php`.

The included `.htaccess` rules protect private folders when using Apache.

### Run locally with PHP

From the extracted `cv_portfolio_professional` folder, run:

```bash
php -S 127.0.0.1:8000 router.php
```

Then open `http://127.0.0.1:8000/`. The included router blocks direct requests to private files during local testing. `.htaccess` is not enforced by PHP's built-in server, so keep the router in the command above. On Apache/Nginx deployment, configure equivalent server rules as described below.

## Configure automatic contact-form email to Gmail

1. Create or open a Google Sheet.
2. Select **Extensions → Apps Script**.
3. Replace the script editor content with `google-apps-script/Code.gs` from this project.
4. In `Code.gs`, replace `replace-with-your-gmail@gmail.com` in `CONTACT_RECIPIENT_EMAIL` with the Gmail inbox that should receive contact messages.
5. Save the script, then choose **Deploy → New deployment → Web app**.
6. Set **Execute as** to **Me**. Choose the access setting suitable for your website; a public portfolio form generally needs access for external visitors, so consider spam protection before publishing.
7. Authorize the requested Google Sheets and email permissions.
8. Set the deployed Web App URL in `SHEETS_WEB_APP_URL` within `assets/js/config.php`.
9. Deploy the website over HTTPS and test using a non-sensitive message. Confirm both the Google Sheet row and the received Gmail message.

**Important:** this project cannot connect to your Gmail account until you supply the intended recipient address, authorize the script, and deploy the endpoint. The browser alone cannot send mail directly through your Gmail account. The included PHP endpoint is a database fallback and does not send email by itself.

## Update images without breaking paths

Keep the filenames unchanged when replacing assets:

- Product covers: `assets/img/products/<slug>.jpg` — each image should be 640 × 460 px.
- Design portfolio: `private_media/designs/design-01.jpg` to `design-40.jpg`.
- Gallery: `private_media/gallery/memory-01.jpg` to `memory-50.jpg`.
- Store banner: `assets/img/toko-banner.jpg`.

All JPG assets are local, so the gallery and product images do not rely on an external image host. Private portrait, design, gallery, and certificate images are served through `media.php` after authentication. Keep filenames unchanged unless you also update `assets/js/app.js` or `assets/js/config.php`.

## Update before publishing

- Replace `Your Name`, email address, WhatsApp number, education details, and any placeholders in `assets/js/config.php` with verified information.
- Confirm company names, job titles, employment dates, training providers, and programme dates.
- Replace sample portrait, design, gallery, and certificate visuals with authentic JPG files you are authorised to publish. Keep private images under `private_media/` and do not move them into a public folder.
- Update `STORE_URL` to the actual Toko Berkah store URL.
- List only software tools and skills that reflect genuine hands-on familiarity.
- For a public form, consider CAPTCHA or another anti-spam measure, rate limiting, HTTPS, and a clear privacy notice.

## CV printing

The ATS CV and cover letter can be opened from the left navigation and printed using the browser print dialog. Choose **Save as PDF** to export a PDF copy.


## Current asset counts
- Design & Portfolio: 40 JPG images stored in `private_media/designs/`.
- Gallery: 50 JPG images stored in `private_media/gallery/`.
- Certificates: 35 JPG placeholders stored in `private_media/certificates/`; replace them only with genuine certificates before use.
- Profile samples: 2 JPG images stored in `private_media/reference/`.
- Store catalogue: 20 JPG product images at 640 × 460 px in `assets/img/products/`.
- All local PNG images were converted to JPG. Software logos that load from third-party CDNs may still use their provider's image format; local fallbacks remain available.
