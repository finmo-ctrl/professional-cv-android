<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
if (!cv_is_authenticated()) { http_response_code(401); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'error'=>'Authentication required']); exit; }
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'error'=>'POST only']); exit; }
$raw=file_get_contents('php://input'); $data=json_decode($raw,true);
if (!is_array($data)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid JSON']); exit; }
$name=trim((string)($data['name']??'')); $email=trim((string)($data['email']??'')); $message=trim((string)($data['message']??''));
if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || $message==='') { http_response_code(422); echo json_encode(['ok'=>false,'error'=>'Required fields missing']); exit; }
$dir=__DIR__.'/../data'; if (!is_dir($dir) && !mkdir($dir,0750,true)) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Storage unavailable']); exit; } if (!is_file($dir.'/.htaccess')) { @file_put_contents($dir.'/.htaccess', "Require all denied\nOptions -Indexes\n"); }
try { $db=new PDO('sqlite:'.$dir.'/contacts.sqlite'); $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); $db->exec('CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT,company TEXT,subject TEXT,message TEXT,created_at TEXT)'); $stmt=$db->prepare('INSERT INTO contacts(name,email,company,subject,message,created_at) VALUES(:name,:email,:company,:subject,:message,:created_at)'); $stmt->execute([':name'=>$name,':email'=>$email,':company'=>substr((string)($data['company']??''),0,160),':subject'=>substr((string)($data['subject']??''),0,180),':message'=>substr($message,0,5000),':created_at'=>date('c')]); echo json_encode(['ok'=>true]); }
catch(Throwable $e){ http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Unable to save message']); }
