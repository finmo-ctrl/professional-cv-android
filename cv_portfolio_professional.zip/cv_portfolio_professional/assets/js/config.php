<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
cv_require_auth();
header('Content-Type: application/javascript; charset=utf-8');
?>
window.CV_CONFIG = {
  "SHEETS_WEB_APP_URL": "https://script.google.com/macros/s/AKfycbxyKw7jhlUNIed0N-mMlkbi7j7RT6zT9PcokESqAUeUk3vAFG6zuDjNu3baaMbOrY_7/exec",
  "AUTO_SLIDE_MS": 5200,
  "STORE_URL": "",
  "PROFILE": {
    "name": "",
    "role": "IT Development, Business & Commercial Operations Analyst",
    "email": "",
    "whatsapp": "",
    "about": "A cross-functional professional with experience in IT development support, Android system implementation and QA testing, commercial analysis, document control, and manufacturing and administrative operations. Combines practical technical support with structured testing, data validation, cost and pricing analysis, digital archiving, and cross-functional coordination. Focused on improving process clarity, information traceability, operational continuity, and evidence-based decision-making."
  },
  "EDUCATION": {
    "major": "",
    "university": "",
    "gpa": ""
  },
  "EXPERIENCES": [
    {
      "id": 10,
      "title": "IT Development, Business & Commercial Operations Analyst",
      "company": "",
      "period": "",
      "category": "Business",
      "summary": "Combines digital process improvement, commercial analysis, document control, and cross-functional operational support across business functions.",
      "jobdesk": [
        "Developed websites and basic internal tools to streamline data management and business workflows, including document-control and warehouse-related processes.",
        "Performed initial troubleshooting of applications, laptops, printers, and network connectivity; escalated unresolved incidents to the relevant IT vendors for further diagnosis and resolution.",
        "Analysed Cost of Goods Sold (COGS), costing, selling prices, Break-Even Point (BEP), Return on Investment (ROI), Gross Profit Margin (GPM), Net Profit Margin (NPM), and overall profitability to support cost control and margin optimisation.",
        "Conducted market research and competitor analysis to identify industry trends, customer needs, commercial opportunities, and positioning considerations.",
        "Sourced products and evaluated domestic and international suppliers against pricing, cost structures, product quality, and negotiation considerations.",
        "Developed business plans, financial projections, business models, and pricing strategies; supported prototype/Minimum Viable Product (MVP) testing and assessed customer feedback for product improvement.",
        "Supported marketing strategies, product launches, distribution, and sales initiatives; prepared pricing analyses, cost simulations, profitability assessments, and commercial recommendations.",
        "Managed document control and physical records through verification, classification, standardisation, numbering, filing, and tracking; digitised hard-copy archives and maintained databases to improve accessibility and traceability.",
        "Supported EXIM administration by preparing and reviewing Commercial Invoices, Packing Lists, and shipping documents; coordinated schedules and shipment updates with freight forwarders and monitored customs documentation and shipment progress.",
        "Maintained accounting transaction documentation and voucher filing; supported General Affairs through facilities, procurement, and maintenance coordination; assisted HR with BPJS administration and recruitment; and supported warehouse goods-receipt/dispatch records, inventory checks, and stocktaking."
      ],
      "achievement": [
        "Supported business-process digitalisation through website development, basic internal tools, and conversion of physical archives into structured digital records.",
        "Improved document organisation and traceability through standardised filing, controlled numbering, and database maintenance.",
        "Provided cost analysis, pricing simulations, margin evaluation, and market research to support commercial decisions and business planning.",
        "Contributed to operational continuity through technical-vendor coordination and cross-functional support across EXIM, HR, GA, accounting, and warehouse activities."
      ],
      "workflow": [
        "Clarify business requirements and operational pain points",
        "Collect and validate business, cost, supplier, and document data",
        "Develop or improve digital workflows and analyse commercial options",
        "Coordinate implementation, document control, and cross-functional actions",
        "Review outcomes, report findings, and follow up on improvements"
      ]
    },
    {
      "id": 9,
      "title": "System Implementer & QA Tester",
      "company": "",
      "period": "",
      "category": "IT",
      "summary": "Supported implementation and quality assurance of an Android sales application used by food-product distribution depots across multiple cities.",
      "jobdesk": [
        "Supported the implementation and day-to-day operation of an Android-based Sales application across food-product distribution depots in multiple cities.",
        "Analysed user requirements and prepared test cases and scenarios based on system specifications and business workflows.",
        "Performed Functional Testing, User Acceptance Testing (UAT), Regression Testing, API Testing, and database validation, as applicable to assigned tasks.",
        "Identified, documented, and tracked software defects in coordination with the Development Team, including clear reproduction steps and supporting evidence.",
        "Conducted troubleshooting, retesting, and technical support to help maintain application stability and depot operations.",
        "Supported system integration, deployment, go-live, and post-implementation activities.",
        "Prepared test reports, defect documentation, SOPs, and user guides while coordinating with developers and end users."
      ],
      "achievement": [
        "Supported application quality and stability through structured testing, data validation, and defect follow-up.",
        "Helped maintain sales operations across multiple depots through troubleshooting and technical coordination.",
        "Improved issue traceability by documenting defects, retest results, and user-facing guidance."
      ],
      "workflow": [
        "Review requirements and operational workflows",
        "Prepare test scenarios, test data, and acceptance criteria",
        "Execute tests and record defects with evidence",
        "Coordinate fixes, retest, and validate data or API behaviour",
        "Support deployment, user guidance, and post-go-live follow-up"
      ]
    },
    {
      "id": 8,
      "title": "Executive Secretary of Director Operations.(Support Engineering Administrator & Document Controller)",
      "company": "",
      "period": "",
      "category": "Admin",
      "summary": "Provided executive administration while supporting engineering records, project coordination, and controlled technical documentation.",
      "jobdesk": [
        "Managed the Operational Director’s calendar, business correspondence, meeting schedules, and interdepartmental coordination.",
        "Arranged business travel, including flight bookings, hotel reservations, transportation, and travel itineraries.",
        "Prepared meeting agendas, documented Minutes of Meeting (MoM), and monitored follow-up actions.",
        "Compiled operational data, prepared management reports, maintained administrative records, and coordinated communication among management, clients, vendors, and internal departments.",
        "Administered Engineering project data, progress tracking, and personnel attendance and overtime records.",
        "Prepared project progress reports, maintained technical documentation, and supported material and equipment procurement administration.",
        "Controlled SOPs, Work Instructions (WI), technical drawings, and project documentation, including document numbering, revision control, distribution, and archiving.",
        "Supported audit preparation by verifying and organising relevant technical documents and records."
      ],
      "achievement": [
        "Supported executive decision-making through calendar management, travel arrangements, meeting coordination, and cross-functional communication.",
        "Improved meeting accountability through documented minutes and follow-up tracking.",
        "Supported Engineering administration through project data management, technical records, and progress reporting.",
        "Maintained document traceability through revision control, controlled distribution, archiving, and audit preparation."
      ],
      "workflow": [
        "Receive requests and establish priorities with management or Engineering",
        "Prepare meeting, travel, project, and document-control records",
        "Verify document versions, approvals, numbering, and distribution",
        "Coordinate action owners and monitor progress",
        "Archive records and prepare evidence for reporting or audits"
      ]
    },
    {
      "id": 7,
      "title": "Receptionist & Administrative Assistant",
      "company": "",
      "period": "",
      "category": "Admin",
      "summary": "Supported front-desk operations, customer relationship administration, vehicle documentation, billing follow-up, and internal coordination.",
      "jobdesk": [
        "Welcomed visitors and customers, handled incoming calls, and managed correspondence and document distribution.",
        "Supported CRO/CRC administration, including customer letters, loyalty cards, and customer or sales-event preparations.",
        "Assisted with STNK/BPKB administration through data entry, document verification, and vehicle-document handover to customers.",
        "Supported billing administration through invoice documentation, data entry, and coordination with vendors and relevant parties.",
        "Assisted HR recruitment administration, General Affairs supplies and operational needs, Sales Advisor coordination, cashier transactions, and initial customer-service support.",
        "Maintained reception and common areas while supporting daily head-office operations."
      ],
      "achievement": [
        "Supported smooth head-office operations and cross-departmental administration.",
        "Helped maintain organised customer, billing, and vehicle-document records.",
        "Contributed to responsive customer service through clear request routing and coordination with relevant teams."
      ],
      "workflow": [
        "Welcome visitors and identify their needs",
        "Route enquiries and documents to the responsible department",
        "Process or coordinate customer, vehicle, billing, and event administration",
        "Track outstanding requests and communicate updates",
        "Maintain accurate records and an orderly reception area"
      ]
    },
    {
      "id": 6,
      "title": "Bank Teller",
      "company": "",
      "period": "",
      "category": "Operations",
      "summary": "Processed customer transactions in line with operating procedures, verification controls, cash-handling requirements, and service standards.",
      "jobdesk": [
        "Processed customer transactions accurately in accordance with standard operating procedures and operational controls.",
        "Verified customer identities, transaction documents, instructions, and supporting requirements before processing.",
        "Managed cash receipts and disbursements and performed daily cash reconciliation.",
        "Recorded and maintained transaction data and supporting documentation accurately and confidentially.",
        "Provided prompt, professional, and customer-focused service while referring exceptions to authorised personnel."
      ],
      "achievement": [
        "Maintained transaction and cash-handling accuracy through consistent verification and SOP compliance.",
        "Supported smooth branch operations through accurate and efficient transaction processing.",
        "Helped minimise transaction errors through careful document checks and data recording."
      ],
      "workflow": [
        "Verify customer identity and transaction instructions",
        "Check transaction documents, amounts, and required authorisation",
        "Process transactions in accordance with SOPs",
        "Reconcile cash and transaction records",
        "Complete daily balancing and closing procedures"
      ]
    },
    {
      "id": 5,
      "title": "Warehouse, Finance & HR Administrator",
      "company": "",
      "period": "",
      "category": "Operations",
      "summary": "Managed warehouse records, material movements, plant-level finance administration, and selected HR support to maintain production and branch continuity.",
      "jobdesk": [
        "Managed warehouse administration and inventory records using Zahir Accounting and Microsoft Excel.",
        "Recorded and controlled incoming and outgoing materials from the warehouse to production, including LBM and supporting documents.",
        "Monitored stock availability through stock cards and Excel and conducted regular stocktaking (stock opname).",
        "Prepared material requests and operational requirements for submission to head office.",
        "Managed shipping documents and material-distribution records and prepared weekly warehouse and operational reports.",
        "Recorded and summarised production employee attendance and supported payroll processing and payslip preparation.",
        "Processed routine operational payments, including Wi-Fi/internet services and other operating expenses.",
        "Coordinated with warehouse, production, head office, and external parties to support daily branch requirements."
      ],
      "achievement": [
        "Strengthened warehouse control through systematic inventory and transaction recording using Excel and Zahir Accounting.",
        "Supported production continuity by monitoring material availability and distribution from warehouse to production.",
        "Improved stock visibility through regular stocktaking and reconciliation of physical quantities against administrative records.",
        "Supported reporting accuracy through structured warehouse, attendance, payroll, and operational data management.",
        "Helped maintain branch operations through routine payment administration and head-office coordination."
      ],
      "workflow": [
        "Record receipts, issues, and supporting material documents",
        "Update stock cards and inventory records",
        "Conduct stocktaking and reconcile physical and recorded balances",
        "Compile attendance, payroll-support, payment, and weekly reports",
        "Submit requirements and reports to head office and follow up discrepancies"
      ]
    },
    {
      "id": 4,
      "title": "Quality Control Inspector (IQC, In-Process QC & EQC)",
      "company": "",
      "period": "",
      "category": "Operations",
      "summary": "Performed incoming, in-process, and final/outgoing quality inspections for automotive wire harness and cable assembly products.",
      "jobdesk": [
        "Conducted Incoming Quality Control (IQC), in-process quality checks, and final/outgoing quality control for automotive wire harness and cable assemblies.",
        "Inspected wires, terminals, connectors, housings, and finished products against drawings, specifications, and customer requirements.",
        "Performed visual and functional inspections using pull-test equipment, checker boards, multimeters, and continuity testing.",
        "Monitored cutting, stripping, crimping, assembly, and soldering processes against defined requirements.",
        "Identified, recorded, and analysed defects and coordinated corrective actions with Production, Engineering, and suppliers.",
        "Maintained quality records and verified product conformity before packing and delivery."
      ],
      "achievement": [
        "Supported consistent quality control from incoming materials through final inspection.",
        "Helped prevent defects and rework through early identification and escalation of nonconformities.",
        "Supported delivery readiness by verifying product conformity before shipment.",
        "Contributed to process improvement using defect analysis and the 7 QC Tools, where applicable."
      ],
      "workflow": [
        "Inspect incoming materials against specifications",
        "Monitor critical production steps and in-process quality",
        "Perform visual, dimensional, and functional checks as assigned",
        "Record defects, analyse trends, and coordinate corrective action",
        "Verify final product conformity and release documentation"
      ]
    },
    {
      "id": 3,
      "title": "Production Operator — Folding Division",
      "company": "",
      "period": "",
      "category": "Operations",
      "summary": "Performed folding and preparation of medical gowns, surgical trousers, and medical linens in line with SOPs, hygiene requirements, quality standards, and production targets.",
      "jobdesk": [
        "Performed folding operations for medical gowns, surgical trousers, and medical linens in accordance with SOPs, work instructions, quality standards, and production targets.",
        "Operated and monitored folding/press machines to maintain smooth and consistent production.",
        "Conducted initial inspections to confirm products were clean and free from stains, defects, loose threads, hair, and other abnormalities.",
        "Ensured accurate, consistent folding to specified standards before packing.",
        "Recorded output and reported process abnormalities or quality issues to the Production Leader or Supervisor.",
        "Complied with K3 occupational safety, hygiene, 5S/5R, and PPE requirements."
      ],
      "achievement": [
        "Achieved up to 105% of daily production targets while maintaining required quality standards, as recorded in the supplied performance information.",
        "Maintained a reported defect rate below 0.2% through consistent inspection and attention to folding accuracy.",
        "Maintained reported 100% attendance during the stated performance period.",
        "Contributed to team productivity by completing assigned targets up to 15 minutes ahead of schedule.",
        "Supported workplace hygiene, safety, and 5S/5R standards in the folding area."
      ],
      "workflow": [
        "Review work instructions and prepare the workstation",
        "Inspect product cleanliness and condition before folding",
        "Operate folding or press equipment and follow standard methods",
        "Check fold consistency, record output, and report abnormalities",
        "Complete packing handover and maintain hygiene, safety, and 5S/5R"
      ]
    },
    {
      "id": 2,
      "title": "Production Operator — Injection Molding",
      "company": "",
      "period": "",
      "category": "Operations",
      "summary": "Operated injection-moulding equipment and monitored output, quality, and process conditions in accordance with standard procedures and safety requirements.",
      "jobdesk": [
        "Operated and monitored injection-moulding machines in accordance with SOPs, process parameters, quality standards, and safety requirements.",
        "Prepared raw materials and performed basic machine start-up and shut-down procedures before and after production.",
        "Conducted routine quality inspections and self-inspection to identify product defects and process abnormalities.",
        "Recorded production output, reject rates, machine downtime, and process issues for daily production reporting.",
        "Maintained 5S, housekeeping, and workplace safety standards within the production area.",
        "Coordinated with Production Leaders and relevant support teams to resolve process abnormalities and maintain production continuity."
      ],
      "achievement": [
        "Supported production targets through consistent machine operation and adherence to standardised processes.",
        "Contributed to product quality through routine inspections and early identification of defects.",
        "Supported production efficiency by responding promptly to machine and process abnormalities.",
        "Contributed to a safe, organised, and productive workplace through consistent 5S and K3 practices."
      ],
      "workflow": [
        "Check work instructions, raw materials, and machine readiness",
        "Perform authorised start-up and monitor machine parameters",
        "Inspect products and record output, rejects, and downtime",
        "Escalate abnormalities and coordinate corrective action",
        "Complete shift records and maintain 5S and safety requirements"
      ]
    },
    {
      "id": 1,
      "title": "Automotive Service Administrator & Technician",
      "company": "",
      "period": "",
      "category": "Admin",
      "summary": "Combined workshop administration with motorcycle inspection, basic diagnostics, repair support, spare-parts tracking, and customer communication.",
      "jobdesk": [
        "Managed service administration, customer records, vehicle data, spare-parts information, and workshop transactions.",
        "Inspected, maintained, and repaired motorcycles in accordance with service standards and work procedures.",
        "Diagnosed mechanical issues and identified required repairs or replacement parts.",
        "Monitored spare-parts usage and supported efficient workshop operations.",
        "Communicated vehicle conditions, service requirements, repair progress, and service results to customers."
      ],
      "achievement": [
        "Improved the organisation of service records and workshop transaction documentation.",
        "Supported timely vehicle diagnosis and repair through systematic inspection and troubleshooting.",
        "Contributed to smooth workshop operations through coordination among customers, technicians, administration, and spare-parts handling."
      ],
      "workflow": [
        "Receive the customer and record reported vehicle concerns",
        "Inspect the motorcycle and identify service requirements",
        "Perform or assist with authorised maintenance and repairs",
        "Track parts, service progress, and transaction details",
        "Explain completed work and maintain service records"
      ]
    }
  ],
  "TRAININGS": [
    {
      "title": "Inventory Control Supervisor Training",
      "provider": "",
      "period": "",
      "description": "Practical training in inventory control across frozen, chilled, and ambient products in retail outlets and Distribution Centres (DCs), with emphasis on stock availability, purchasing controls, inventory accuracy, KPI monitoring, and supply-chain continuity.",
      "modules": [
        "Inventory control for frozen, chilled, and ambient products across retail outlets and DCs; stock availability, stockout prevention, and overstock control.",
        "Purchase Order (PO) monitoring, supplier delivery follow-up, goods receipt, and delivery-note reconciliation.",
        "Periodic stock counts and inventory audits; investigation of discrepancies, losses, damages, and returns; Root Cause Analysis (RCA) and corrective actions.",
        "Inventory movement, sales-trend, replenishment, purchasing-requirement, and supply-demand analysis.",
        "Cross-functional coordination with Store Operations, Purchasing, Merchandising, Warehouse, Logistics, Distribution, and suppliers.",
        "Periodic inventory reporting, KPI monitoring, team performance evaluation, inventory accuracy, and operational compliance."
      ],
      "workflow": [
        "Review stock availability, movement, sales trends, and replenishment requirements",
        "Monitor POs, supplier deliveries, goods receipts, and delivery-note reconciliation",
        "Supervise stock counts and audits; reconcile records and investigate variances",
        "Conduct root-cause analysis and coordinate corrective actions with relevant teams",
        "Prepare inventory reports, review KPIs, and follow up on control improvements"
      ],
      "outcome": "Built a practical understanding of inventory accuracy controls, stock availability optimisation, procurement and goods-receipt verification, discrepancy investigation, KPI-based reporting, and cross-functional supply-chain coordination. The programme content also covered supporting stock accuracy through stocktaking and reconciliation, improving replenishment decisions through movement analysis, strengthening PO and delivery-document controls, and supporting operational efficiency through structured reporting.",
      "achievements": [
        "Supported inventory accuracy through supervised stocktaking, data reconciliation, and systematic follow-up on discrepancies.",
        "Contributed to stock availability optimisation through movement analysis, purchasing-requirement reviews, and supply-chain coordination.",
        "Strengthened PO and goods-receipt controls through delivery-document verification.",
        "Supported operational efficiency through KPI monitoring, structured reporting, and cross-functional coordination."
      ]
    },
    {
      "title": "Industrial Digitalization Training",
      "provider": "",
      "period": "",
      "description": "Focused on Business Development and System Implementation, including Industry 4.0 client visits across Greater Jakarta (Jabodetabek), on-site Gemba Walks, business requirements analysis, digital-solution alignment, software testing, and operational documentation.",
      "modules": [
        "Industry 4.0 opportunities and client engagement across manufacturing, biotechnology, and related industrial sectors in Jabodetabek.",
        "Post-meeting Gemba Walks and on-site operational assessments in production areas to identify business requirements, operational challenges, and digitalisation opportunities.",
        "Digital-solution presentations, client requirement analysis, and cross-functional alignment with the Development Team.",
        "Application testing, software-defect documentation, and system implementation readiness.",
        "Preparation of user manuals, Standard Operating Procedures (SOPs), and application documentation to support consistent system adoption."
      ],
      "workflow": [
        "Visit prospective clients and discuss operational challenges and digitalisation needs",
        "Conduct Gemba Walks and assess on-site workflows and requirements",
        "Translate business needs into structured requirements and coordinate with the Development Team",
        "Support application testing, document defects, and follow up corrective actions",
        "Prepare user manuals, SOPs, and implementation documentation"
      ],
      "outcome": "Developed practical exposure to Industry 4.0 client engagement, Gemba-based operational assessment, business-to-technical requirements alignment, application testing, and implementation documentation. Contributed to identifying digitalisation opportunities, clarifying business requirements, supporting implementation readiness, and improving procedural consistency through user manuals and SOPs.",
      "achievements": [
        "Contributed to identifying Industry 4.0 digitalisation opportunities through cross-sector client visits and on-site operational assessments.",
        "Helped align client requirements with digital solutions through structured analysis and collaboration with the Development Team.",
        "Supported implementation readiness through application testing, technical-issue documentation, and corrective-action coordination.",
        "Prepared user manuals, SOPs, and supporting documentation to improve procedural clarity and consistent application use."
      ]
    },
    {
      "title": "Junior Web Developer (Training Program)",
      "provider": "",
      "period": "",
      "description": "Hands-on web-development training covering application development, database management, MVC and responsive-design concepts, software testing, debugging, and development collaboration using common web technologies and tools.",
      "modules": [
        "Web application development with PHP, Laravel, CodeIgniter, HTML5, CSS, JavaScript, jQuery, Bootstrap, and Vue.js.",
        "Database concepts and data management using SQL Server and Oracle.",
        "MVC architecture, responsive web development, Software Development Life Cycle (SDLC), and basic UI/UX principles.",
        "Debugging, troubleshooting, functional testing, and bug fixing to improve application stability.",
        "Git/GitHub for version control and code collaboration; development tools including Visual Studio Code, IntelliJ IDEA, and NetBeans.",
        "Web application architecture, database management, programming fundamentals, and software-development best practices."
      ],
      "workflow": [
        "Review application requirements and specifications",
        "Plan application structure, interface, and database interactions",
        "Develop front-end components and server-side functionality",
        "Test, debug, troubleshoot, and fix defects",
        "Use version control and document the implementation and results"
      ],
      "outcome": "Established a practical foundation in web application development, database concepts, MVC and responsive design, debugging, and version control. Applied programming and data-management concepts in training exercises and strengthened problem-solving through testing and defect resolution.",
      "achievements": [
        "Built a strong foundation in web application development through hands-on programming and structured technical training.",
        "Applied programming, database, debugging, and version-control concepts in practical development exercises.",
        "Improved technical problem-solving through application testing, troubleshooting, and bug resolution."
      ]
    },
    {
      "title": "Full Stack Programmers — IT Fundamental Programming",
      "provider": "",
      "period": "",
      "description": "Foundational programming training covering computational thinking, algorithms, programming logic, object-oriented concepts, basic data structures, version control, and introductory web and application development.",
      "modules": [
        "Programming logic, algorithms, problem decomposition, flowcharts, and structured code-writing practices.",
        "Object-oriented programming (OOP), variables, data types, conditions, loops, functions, and basic data structures.",
        "Programming languages and technologies: Python, JavaScript, PHP, HTML/CSS, Bootstrap, and React.js.",
        "Version control and collaboration using Git and GitHub.",
        "Android application fundamentals using Android Studio and Kotlin/Java; XML Layout and Material Design interfaces.",
        "Activity/Intent navigation, application debugging, SQLite/Room local storage, REST API integration, JSON processing, and Android application builds.",
        "Practical application exercises, CRUD functionality, multi-screen navigation, dynamic-data display, and source-code publication to GitHub."
      ],
      "workflow": [
        "Break a programming problem into manageable requirements and logical steps",
        "Design the algorithm and implement core program logic",
        "Build an interface and connect the required application flow or data handling",
        "Test input validation, navigation, CRUD operations, and API data handling; debug issues",
        "Manage source code with Git/GitHub and prepare an APK build for testing"
      ],
      "outcome": "Developed foundational programming logic, algorithmic thinking, and practical software-development skills. Training exercises covered basic Android interfaces and multi-screen navigation, local CRUD data storage, introductory REST API integration, debugging, and GitHub-based source-code management, including APK builds for testing.",
      "achievements": [
        "Built foundational programming logic, algorithmic thinking, and structured problem-solving skills.",
        "Developed a basic Android application with interactive interfaces and multi-screen navigation.",
        "Implemented local data storage and CRUD functionality and practised REST API integration for dynamic data.",
        "Managed project source code using Git/GitHub and generated APK builds for testing."
      ]
    }
  ],
  "SKILLS": [
    {
      "icon": "⌘",
      "title": "Web Development & Technical Support",
      "description": "Website and internal-tool development fundamentals, requirements analysis, technical troubleshooting, and user support.",
      "tags": [
        "HTML/CSS/JavaScript",
        "PHP & MVC",
        "System support"
      ]
    },
    {
      "icon": "✓",
      "title": "Quality Assurance & System Implementation",
      "description": "Functional and regression testing, UAT support, API testing exposure, defect reporting, retesting, database validation, deployment support, and user documentation.",
      "tags": [
        "Test cases",
        "Bug lifecycle",
        "Implementation"
      ]
    },
    {
      "icon": "◫",
      "title": "Business & Commercial Analysis",
      "description": "COGS, costing, pricing, BEP, ROI, GPM, NPM, marketplace fees, cost control, market research, competitor analysis, supplier evaluation, and business planning.",
      "tags": [
        "Cost & pricing",
        "Market research",
        "Profitability"
      ]
    },
    {
      "icon": "▤",
      "title": "Operations, Inventory & Administration",
      "description": "Warehouse records, material movements, stocktaking, transaction reconciliation, purchasing documents, reporting, and cross-functional coordination.",
      "tags": [
        "Inventory control",
        "Reporting",
        "Operations"
      ]
    },
    {
      "icon": "▧",
      "title": "Document Control & Digital Archiving",
      "description": "Document verification, classification, numbering, revision control, controlled distribution, physical and digital filing, traceability, SOP/WI administration, and database maintenance.",
      "tags": [
        "Revision control",
        "Digital records",
        "SOP/WI"
      ]
    },
    {
      "icon": "◎",
      "title": "Coordination & Process Improvement",
      "description": "Structured communication, action tracking, issue escalation, procedural consistency, operational follow-up, and continuous-improvement support.",
      "tags": [
        "Coordination",
        "Problem solving",
        "Process improvement"
      ]
    }
  ],
  "DESIGNS": [
    "Brand Identity Exploration",
    "Social Media Campaign",
    "Lifestyle Product Poster",
    "Editorial Cover Concept",
    "Cosmetic Product Visual",
    "Food & Beverage Promotion",
    "Fashion Catalogue Layout",
    "Event Poster Design",
    "Minimal Packaging Mock-up",
    "Digital Advertisement",
    "Coffee Branding Study",
    "Skincare Product Retouch",
    "Local Product Campaign",
    "Typography Composition",
    "Corporate Brochure Design",
    "Jersey Promotion Visual",
    "Novel Cover Concept",
    "Pre-loved Product Campaign",
    "Garden Product Poster",
    "Mobile UI Visual Concept",
    "Landing Page Art Direction",
    "Seasonal Sale Campaign",
    "Product Photo Retouch",
    "Photo Manipulation Study",
    "Marketplace Banner Design",
    "Infographic Layout",
    "Logo Exploration",
    "Packaging Mock-up",
    "Website Hero Banner",
    "Creative Composite Artwork",
    "Corporate Identity System",
    "Product Packaging Study",
    "Retail Campaign Artwork",
    "Professional Profile Layout",
    "Digital Product Catalogue",
    "Business Presentation Design",
    "Promotional Flyer Concept",
    "Brand Colour Exploration",
    "E-commerce Product Card",
    "Social Media Carousel"
],
  "PROJECTS": [
    {
      "title": "Document Control Website",
      "category": "Website Prototype",
      "image": "assets/img/projects/project-01.jpg",
      "url": "projects/document-control/index.html",
      "description": "A conceptual interface for document registration, search, revision tracking, approval status, and digital archiving.",
      "tools": "HTML5, CSS3, Vanilla JavaScript",
      "year": "Conceptual prototype"
    },
    {
      "title": "Warehouse Inventory System",
      "category": "Web Application Prototype",
      "image": "assets/img/projects/project-02.jpg",
      "url": "projects/warehouse-system/index.html",
      "description": "A warehouse dashboard concept for stock summaries, goods receipts and issues, inventory lists, and low-stock indicators. All data is simulated.",
      "tools": "HTML5, CSS3, Vanilla JavaScript",
      "year": "Conceptual prototype"
    },
    {
      "title": "Android Inventory App Concept",
      "category": "Mobile UI Prototype",
      "image": "assets/img/projects/project-03.jpg",
      "url": "projects/android-inventory/index.html",
      "description": "A responsive concept for a mobile inventory interface with stock summaries, item records, transaction capture, and item details. This is a web-based UI prototype, not a production APK.",
      "tools": "Mobile-first UI, HTML, CSS, JavaScript",
      "year": "Conceptual prototype"
    }
  ],
  "GALLERY": [
    "Professional Profile",
    "Team Collaboration",
    "Workshop Session",
    "Project Coordination",
    "Office Activities",
    "Learning Moment",
    "Production Visit",
    "Team Appreciation",
    "Project Milestone",
    "Company Event",
    "Creative Discussion",
    "Training Day",
    "Workplace Snapshot",
    "Team Celebration",
    "Knowledge Sharing",
    "Professional Journey",
    "Business Meeting",
    "Technical Review",
    "Team Briefing",
    "Training Workshop",
    "Operational Visit",
    "Project Discussion",
    "Workplace Learning",
    "Team Activity",
    "Process Review",
    "Professional Development",
    "Knowledge Exchange",
    "Collaborative Planning",
    "Quality Review",
    "Career Reflection",
    "Client Meeting",
    "Digitalisation Workshop",
    "Warehouse Operations",
    "Document Review",
    "Quality Inspection",
    "Product Planning",
    "Team Huddle",
    "Office Preparation",
    "Business Presentation",
    "Technical Support",
    "Process Improvement",
    "Learning Session",
    "Project Handover",
    "Workplace Safety",
    "Career Milestone",
    "Formal Workplace Portrait",
    "Formal Workplace Portrait",
    "Formal Workplace Portrait",
    "Formal Workplace Portrait",
    "Formal Workplace Portrait"
],
  "PRODUCTS": [
    {
      "slug": "bandung-po",
      "title": "Bandung Souvenir Pre-Orders",
      "desc": "Pre-order signature snacks and local favourites from Bandung."
    },
    {
      "slug": "garut-po",
      "title": "Garut Souvenir Pre-Orders",
      "desc": "Discover regional snacks and traditional specialties from Garut."
    },
    {
      "slug": "preloved-clothes",
      "title": "Pre-loved Clothing",
      "desc": "Affordable second-hand clothing selected for everyday wear."
    },
    {
      "slug": "preloved-home",
      "title": "Pre-loved Home Essentials",
      "desc": "Useful household items offered in good, clearly described condition."
    },
    {
      "slug": "bags",
      "title": "Crossbody Bags & Backpacks",
      "desc": "Practical sling bags and backpacks for daily activities and travel."
    },
    {
      "slug": "grape-seedlings",
      "title": "Grape Seedlings & Fertiliser",
      "desc": "Grape seedlings paired with fertiliser packages for home gardening."
    },
    {
      "slug": "baduy-honey",
      "title": "Authentic Baduy Honey",
      "desc": "Natural honey sourced as Baduy honey; product details should be verified with the supplier."
    },
    {
      "slug": "fresh-vegetables",
      "title": "Fresh Farm Vegetables",
      "desc": "Fresh harvests including water spinach, spinach, cassava leaves, kenikir, basil, cucumber, golden melon, squash, round eggplant, curly mustard greens, and radish leaves."
    },
    {
      "slug": "football-jerseys",
      "title": "Football Jerseys",
      "desc": "Football jerseys for fans, casual wear, and team-inspired collections."
    },
    {
      "slug": "novels",
      "title": "Fiction & Lifestyle Novels",
      "desc": "A varied reading collection covering horror, romance, friendship, family, workplace, and office life."
    },
    {
      "slug": "barber-pomade",
      "title": "Barbershop Pomade",
      "desc": "Styling pomade for barbershop use and everyday grooming."
    },
    {
      "slug": "game-services",
      "title": "Mobile Legends & Roblox Gaming Services",
      "desc": "Gaming assistance services for Mobile Legends and Roblox, subject to platform rules."
    },
    {
      "slug": "online-listening",
      "title": "Online Listening & Conversation",
      "desc": "A confidential, respectful online conversation service for sharing thoughts and everyday concerns; not a substitute for professional care."
    },
    {
      "slug": "tshirts",
      "title": "Plain & Graphic T-shirts",
      "desc": "Everyday plain T-shirts and graphic designs for casual styling."
    },
    {
      "slug": "fresh-fruit",
      "title": "Fresh Orchard Fruit",
      "desc": "Seasonal fruit sourced directly from the tree or orchard when available."
    },
    {
      "slug": "coffee",
      "title": "Robusta & Arabica Coffee",
      "desc": "Coffee selections featuring Robusta and Arabica beans for different flavour preferences."
    },
    {
      "slug": "palm-sugar",
      "title": "Authentic Garut Palm Sugar",
      "desc": "Traditional palm sugar from Garut for drinks, desserts, and home cooking."
    },
    {
      "slug": "daily-needs",
      "title": "Everyday Essentials",
      "desc": "Practical household and daily-use items for routine needs."
    },
    {
      "slug": "collectible-currency",
      "title": "Vintage Banknotes & Coins",
      "desc": "A collectible selection that may include Singaporean and Arabic banknotes, Japanese coins, and Indonesian coins."
    },
    {
      "slug": "toko-berkah",
      "title": "Toko Berkah Featured Finds",
      "desc": "Explore a varied catalogue of products and services from Toko Berkah."
    }
  ],
  "CERTIFICATES": [
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample",
    "sample"
  ],
  "SOFTWARE_GROUPS": [
  {
    "title": "Web Development Tools",
    "items": [
      "Visual Studio Code (VS Code)",
      "HTML5",
      "CSS3",
      "JavaScript",
      "PHP",
      "Bootstrap",
      "jQuery",
      "Laravel",
      "CodeIgniter",
      "Vue.js",
      "NetBeans"
    ]
  },
  {
    "title": "Mobile Development & QA Testing",
    "items": [
      "Android Studio",
      "Kotlin",
      "Java",
      "XML Layout",
      "SQLite/Room",
      "REST API",
      "JSON",
      "Git",
      "GitHub"
    ]
  },
  {
    "title": "Office & Data Management",
    "items": [
      "Microsoft Excel",
      "Microsoft Word",
      "Microsoft PowerPoint"
    ]
  },
  {
    "title": "ERP, Accounting & Inventory",
    "items": [
      "SAP",
      "Zahir Accounting",
      "MYOB"
    ]
  },
  {
    "title": "Design & Digital Content",
    "items": [
      "Adobe Photoshop",
      "Video Editing Software"
    ]
  }
],
  "HERO_SLIDES": [
    {
      "src": "media.php?file=reference%2Fprofile-sample-01.jpg",
      "caption": "Illustrative professional portrait placeholder"
    },
    {
      "src": "media.php?file=reference%2Fprofile-sample-02.jpg",
      "caption": "Alternative illustrative portrait placeholder"
    }
  ],
  "PRODUCT_TRANSLATIONS": {
    "id": [
      [
        "Oleh-Oleh Bandung (PO)",
        "PO camilan khas dan oleh-oleh pilihan dari Bandung."
      ],
      [
        "Oleh-Oleh Garut (PO)",
        "Pesan camilan daerah dan makanan khas Garut."
      ],
      [
        "Pakaian Preloved",
        "Pakaian bekas pilihan dengan harga terjangkau untuk pemakaian sehari-hari."
      ],
      [
        "Barang Rumah Tangga Preloved",
        "Perlengkapan rumah tangga yang masih layak pakai dengan kondisi dijelaskan secara transparan."
      ],
      [
        "Tas Selempang & Ransel",
        "Tas praktis untuk aktivitas sehari-hari dan perjalanan."
      ],
      [
        "Bibit Anggur & Pupuk",
        "Bibit anggur dan paket pupuk untuk kebutuhan berkebun di rumah."
      ],
      [
        "Madu Baduy Asli",
        "Madu yang dipasarkan sebagai madu Baduy; detail produk perlu diverifikasi dengan pemasok."
      ],
      [
        "Sayuran Segar dari Ladang",
        "Hasil panen seperti kangkung, bayam, daun singkong, kenikir, kemangi, timun, timun suri, labu sayur, terong bulat, sawi keriting, dan daun lobak."
      ],
      [
        "Jersey Sepak Bola",
        "Jersey sepak bola untuk penggemar, pemakaian kasual, dan koleksi bertema tim."
      ],
      [
        "Novel Fiksi & Kehidupan",
        "Pilihan novel horor, romantis, persahabatan, keluarga, dunia kerja, dan kehidupan kantor."
      ],
      [
        "Pomade Barbershop",
        "Pomade untuk kebutuhan barbershop dan penataan rambut sehari-hari."
      ],
      [
        "Jasa Game Mobile Legends & Roblox",
        "Layanan bantuan game Mobile Legends dan Roblox dengan tetap mengikuti ketentuan platform."
      ],
      [
        "Jasa Curhat Online",
        "Layanan percakapan online yang menghargai privasi untuk berbagi cerita dan kekhawatiran sehari-hari; bukan pengganti layanan profesional."
      ],
      [
        "Kaos Polos & Bergambar",
        "Kaos polos sehari-hari dan kaos dengan desain grafis untuk gaya kasual."
      ],
      [
        "Buah Segar dari Kebun",
        "Buah musiman yang dipetik langsung dari pohon atau kebun sesuai ketersediaan."
      ],
      [
        "Kopi Robusta & Arabika",
        "Pilihan kopi Robusta dan Arabika dengan karakter rasa yang beragam."
      ],
      [
        "Gula Aren Asli Garut",
        "Gula aren tradisional dari Garut untuk minuman, hidangan penutup, dan masakan rumahan."
      ],
      [
        "Kebutuhan Harian",
        "Barang rumah tangga dan kebutuhan praktis untuk pemakaian rutin."
      ],
      [
        "Uang Kuno & Koleksi Koin",
        "Koleksi yang dapat mencakup uang kertas Singapura dan Arab, serta koin Jepang dan Indonesia."
      ],
      [
        "Pilihan Toko Berkah",
        "Jelajahi beragam produk dan layanan pilihan dari Toko Berkah."
      ]
    ],
    "en": [
      [
        "Bandung Souvenir Pre-Orders",
        "Pre-order signature snacks and local favourites from Bandung."
      ],
      [
        "Garut Souvenir Pre-Orders",
        "Discover regional snacks and traditional specialties from Garut."
      ],
      [
        "Pre-loved Clothing",
        "Affordable second-hand clothing selected for everyday wear."
      ],
      [
        "Pre-loved Home Essentials",
        "Useful household items offered in good, clearly described condition."
      ],
      [
        "Crossbody Bags & Backpacks",
        "Practical sling bags and backpacks for daily activities and travel."
      ],
      [
        "Grape Seedlings & Fertiliser",
        "Grape seedlings paired with fertiliser packages for home gardening."
      ],
      [
        "Authentic Baduy Honey",
        "Natural honey sourced as Baduy honey; product details should be verified with the supplier."
      ],
      [
        "Fresh Farm Vegetables",
        "Fresh harvests including water spinach, spinach, cassava leaves, kenikir, basil, cucumber, golden melon, squash, round eggplant, curly mustard greens, and radish leaves."
      ],
      [
        "Football Jerseys",
        "Football jerseys for fans, casual wear, and team-inspired collections."
      ],
      [
        "Fiction & Lifestyle Novels",
        "A varied reading collection covering horror, romance, friendship, family, workplace, and office life."
      ],
      [
        "Barbershop Pomade",
        "Styling pomade for barbershop use and everyday grooming."
      ],
      [
        "Mobile Legends & Roblox Gaming Services",
        "Gaming assistance services for Mobile Legends and Roblox, subject to platform rules."
      ],
      [
        "Online Listening & Conversation",
        "A confidential, respectful online conversation service for sharing thoughts and everyday concerns; not a substitute for professional care."
      ],
      [
        "Plain & Graphic T-shirts",
        "Everyday plain T-shirts and graphic designs for casual styling."
      ],
      [
        "Fresh Orchard Fruit",
        "Seasonal fruit sourced directly from the tree or orchard when available."
      ],
      [
        "Robusta & Arabica Coffee",
        "Coffee selections featuring Robusta and Arabica beans for different flavour preferences."
      ],
      [
        "Authentic Garut Palm Sugar",
        "Traditional palm sugar from Garut for drinks, desserts, and home cooking."
      ],
      [
        "Everyday Essentials",
        "Practical household and daily-use items for routine needs."
      ],
      [
        "Vintage Banknotes & Coins",
        "A collectible selection that may include Singaporean and Arabic banknotes, Japanese coins, and Indonesian coins."
      ],
      [
        "Toko Berkah Featured Finds",
        "Explore a varied catalogue of products and services from Toko Berkah."
      ]
    ],
    "ko": [
      [
        "반둥 기념품 예약 주문",
        "반둥 지역의 대표 간식과 특산품을 사전 주문할 수 있습니다."
      ],
      [
        "가룻 기념품 예약 주문",
        "가룻 지역의 전통 간식과 특산품을 만나보세요."
      ],
      [
        "중고 의류",
        "일상복으로 활용하기 좋은 합리적인 가격의 중고 의류입니다."
      ],
      [
        "중고 생활용품",
        "상태를 명확히 안내하는 실용적인 중고 가정용품입니다."
      ],
      [
        "크로스백 및 백팩",
        "일상과 여행에 적합한 실용적인 가방입니다."
      ],
      [
        "포도 묘목 및 비료",
        "가정 원예용 포도 묘목과 비료 패키지입니다."
      ],
      [
        "바두이 천연 꿀",
        "바두이 꿀로 판매되는 제품이며 공급처를 통해 세부 정보를 확인해야 합니다."
      ],
      [
        "신선한 농장 채소",
        "수확 시기에 따라 다양한 신선 채소를 제공합니다."
      ],
      [
        "축구 유니폼",
        "축구 팬과 일상복을 위한 유니폼입니다."
      ],
      [
        "소설 도서",
        "공포, 로맨스, 우정, 가족, 직장 생활을 다루는 소설입니다."
      ],
      [
        "바버샵 포마드",
        "바버샵 및 일상 헤어 스타일링용 포마드입니다."
      ],
      [
        "모바일 레전드 및 로블록스 서비스",
        "플랫폼 규정을 준수하는 게임 지원 서비스입니다."
      ],
      [
        "온라인 대화 서비스",
        "일상의 생각을 나누는 존중 기반 온라인 대화 서비스이며 전문 상담을 대체하지 않습니다."
      ],
      [
        "무지 및 그래픽 티셔츠",
        "캐주얼 스타일을 위한 기본 티셔츠와 그래픽 티셔츠입니다."
      ],
      [
        "신선한 과일",
        "수확 가능 여부에 따라 나무나 과수원에서 직접 공급하는 제철 과일입니다."
      ],
      [
        "로부스타 및 아라비카 커피",
        "다양한 풍미의 로부스타와 아라비카 커피입니다."
      ],
      [
        "가룻 팜슈거",
        "음료와 요리에 활용할 수 있는 가룻 전통 팜슈거입니다."
      ],
      [
        "생활 필수품",
        "일상에 필요한 실용적인 생활용품입니다."
      ],
      [
        "빈티지 지폐 및 동전",
        "싱가포르·아랍 지폐와 일본·인도네시아 동전 등을 포함할 수 있습니다."
      ],
      [
        "토코 버르카 추천 상품",
        "토코 버르카의 다양한 상품과 서비스를 둘러보세요."
      ]
    ],
    "ja": [
      [
        "バンドン名産品の予約注文",
        "バンドンの名物スナックや特産品を予約注文できます。"
      ],
      [
        "ガルト名産品の予約注文",
        "ガルト地方の伝統菓子や特産品をお届けします。"
      ],
      [
        "中古衣料",
        "日常使いに適した手頃な価格の中古衣料です。"
      ],
      [
        "中古家庭用品",
        "状態を明確に案内する実用的な中古家庭用品です。"
      ],
      [
        "ショルダーバッグ・リュック",
        "普段使いや旅行に便利なバッグです。"
      ],
      [
        "ブドウ苗と肥料",
        "家庭菜園向けのブドウ苗と肥料セットです。"
      ],
      [
        "バドゥイ産はちみつ",
        "バドゥイ産として販売する蜂蜜です。詳細は仕入先に確認してください。"
      ],
      [
        "農園直送の新鮮野菜",
        "収穫状況に応じてさまざまな新鮮野菜を提供します。"
      ],
      [
        "サッカージャージ",
        "サッカーファンや普段着向けのジャージです。"
      ],
      [
        "小説",
        "ホラー、恋愛、友情、家族、職場をテーマにした小説です。"
      ],
      [
        "バーバー用ポマード",
        "理髪店や日常のヘアスタイリング向けポマードです。"
      ],
      [
        "ゲームサポートサービス",
        "各プラットフォームの規約に従ったゲーム支援サービスです。"
      ],
      [
        "オンライン傾聴サービス",
        "日常の悩みを共有できる尊重を大切にした会話サービスです。専門的ケアの代替ではありません。"
      ],
      [
        "無地・プリントTシャツ",
        "カジュアルな無地TシャツとグラフィックTシャツです。"
      ],
      [
        "採れたて果物",
        "収穫状況に応じて木や果樹園から直接仕入れる季節の果物です。"
      ],
      [
        "ロブスタ・アラビカコーヒー",
        "異なる風味を楽しめるロブスタとアラビカです。"
      ],
      [
        "ガルト産パームシュガー",
        "飲み物や料理に使えるガルトの伝統的なパームシュガーです。"
      ],
      [
        "日用品",
        "毎日の暮らしに役立つ実用的な商品です。"
      ],
      [
        "アンティーク紙幣・硬貨",
        "シンガポールやアラブの紙幣、日本・インドネシアの硬貨などを含みます。"
      ],
      [
        "トコ・ベルカおすすめ商品",
        "トコ・ベルカの多彩な商品とサービスをご覧ください。"
      ]
    ],
    "zh": [
      [
        "万隆特产预订",
        "预订万隆特色零食和地方特产。"
      ],
      [
        "加鲁特特产预订",
        "选购加鲁特传统小吃与地方特色产品。"
      ],
      [
        "二手服装",
        "价格实惠、适合日常穿着的精选二手服装。"
      ],
      [
        "二手家居用品",
        "实用的二手家居用品，并清楚说明商品状况。"
      ],
      [
        "斜挎包与背包",
        "适合日常活动和旅行的实用包袋。"
      ],
      [
        "葡萄苗与肥料",
        "适合家庭园艺的葡萄苗及肥料套装。"
      ],
      [
        "巴杜伊天然蜂蜜",
        "以巴杜伊蜂蜜名义销售；具体信息请向供应商核实。"
      ],
      [
        "新鲜农场蔬菜",
        "根据收成供应多种新鲜蔬菜。"
      ],
      [
        "足球球衣",
        "适合球迷和日常休闲穿着的足球球衣。"
      ],
      [
        "小说读物",
        "涵盖恐怖、爱情、友情、家庭及职场主题的小说。"
      ],
      [
        "理发店发油",
        "适合理发店及日常造型使用的发油。"
      ],
      [
        "手游与 Roblox 游戏服务",
        "遵守平台规则的游戏辅助服务。"
      ],
      [
        "在线倾听服务",
        "提供尊重与隐私优先的线上交流，不替代专业服务。"
      ],
      [
        "纯色与图案 T 恤",
        "适合休闲穿搭的纯色及图案 T 恤。"
      ],
      [
        "新鲜水果",
        "根据供应情况提供直接来自果树或果园的时令水果。"
      ],
      [
        "罗布斯塔与阿拉比卡咖啡",
        "提供风味各异的罗布斯塔和阿拉比卡咖啡。"
      ],
      [
        "加鲁特原产棕榈糖",
        "适用于饮品、甜点和家常烹饪的传统棕榈糖。"
      ],
      [
        "日常必需品",
        "满足日常生活需要的实用商品。"
      ],
      [
        "古董纸币与硬币",
        "可能包括新加坡和阿拉伯纸币，以及日本和印尼硬币。"
      ],
      [
        "Berkah 精选商品",
        "浏览 Toko Berkah 的多样商品与服务。"
      ]
    ]
  },
  "UI_TRANSLATIONS": {
    "en": {
      "storeIntro": "A curated selection of products and services for everyday needs, local discoveries, and personal interests.",
      "storeBannerTitle": "Discover thoughtful, fresh, and practical finds.",
      "storeBannerText": "Local specialities · Garden harvests · Everyday essentials · Digital services",
      "visitStore": "Visit Berkah Store ↗",
      "productsTitle": "Products & Services",
      "productsIntro": "Browse the catalogue below. Product availability, condition, and service terms should be confirmed before ordering.",
      "designIntro": "Creative concepts, promotional visuals, image retouching, and digital project presentations. Select a JPG image to explore its details.",
      "galleryIntro": "A professional gallery for workplace portraits, team photographs, meeting-room moments, formal events, training sessions, and office activities. Replace sample visuals with your own authorised photographs.",
      "contactIntro": "Available for professional discussions, project collaboration, employment opportunities, and portfolio-related enquiries.",
      "contactHeading": "Every meaningful collaboration begins with a clear conversation.",
      "contactBody": "Use the form to send a message. Online delivery requires the Google Apps Script endpoint to be configured.",
      "contactForm": "Contact Form",
      "sendMessage": "Send Message",
      "fullName": "Full Name",
      "emailAddress": "Active Email Address",
      "company": "Company (Optional)",
      "subject": "Subject",
      "message": "Message",
      "secureForm": "Secure Form",
      "submitPending": "Submitting your message…",
      "submitSuccess": "Thank you. Your message has been submitted to the configured delivery endpoint.",
      "submitFail": "The message could not be delivered. Check the web app URL and recipient email settings.",
      "softwareIntro": "Tools relevant to the experience and training described. Please list only tools that reflect your actual hands-on familiarity.",
      "productsCount": "20 CATEGORIES",
      "galleryCount": "50 JPG IMAGES",
      "designCount": "30 JPG VISUALS",
      "submitSuccessLocal": "Your message was saved on the website server. Configure Google Apps Script to email it to Gmail.",
      "designSub": "Creative JPG concept",
      "interfaceLanguage": "Interface Language",
      "themeMode": "Dark / Light Mode",
      "openToOpportunities": "Open to opportunities",
      "aboutBody": "Committed to accuracy, structured execution, cross-functional collaboration, and continuous improvement. Combines practical operational understanding with a digital mindset to help teams work consistently and make data-informed decisions.",
      "experienceIntro": "Ten cross-functional roles spanning manufacturing operations, system implementation, and business analysis.",
      "trainingIntro": "Professional development programmes covering structured learning modules, workflows, and outcomes aligned with practical industry requirements.",
      "designSubheading": "Photoshop & Creative Design",
      "projectSubheading": "Digital Projects",
      "projectIntro": "Conceptual demonstrations of internal websites and application interfaces.",
      "sliderHint": "Swipe horizontally or use the arrow controls. Select a card to view details.",
      "galleryHint": "Swipe with a touch screen, drag horizontally, or use the arrow controls. Select an image to enlarge it.",
      "locationLabel": "Location",
      "contactLocation": "Bekasi · Indonesia",
      "footerTagline": "Designed with clarity, crafted for opportunities.",
      "backToTop": "Back to top ↑",
      "heroDesc": "A cross-functional professional combining system support, quality assurance, commercial analysis, document control, and operational coordination.",
      "profileSummary": "A cross-functional professional with experience in IT development support, Android system implementation and QA testing, commercial analysis, document control, and manufacturing and administrative operations. Combines practical technical support with structured testing, data validation, cost and pricing analysis, digital archiving, and cross-functional coordination. Focused on improving process clarity, information traceability, operational continuity, and evidence-based decision-making.",
      "roleTitle": "IT Development, Business & Commercial Operations Analyst"
    },
    "id": {
      "storeIntro": "Pilihan produk dan layanan untuk kebutuhan harian, produk khas daerah, dan minat pribadi.",
      "storeBannerTitle": "Temukan produk pilihan yang segar, praktis, dan bermanfaat.",
      "storeBannerText": "Oleh-oleh daerah · Hasil kebun · Kebutuhan harian · Layanan digital",
      "visitStore": "Kunjungi Toko Berkah ↗",
      "productsTitle": "Produk & Layanan",
      "productsIntro": "Jelajahi katalog berikut. Pastikan ketersediaan, kondisi barang, dan ketentuan layanan sebelum memesan.",
      "designIntro": "Konsep kreatif, materi promosi, retouching gambar, dan presentasi proyek digital. Pilih gambar JPG untuk melihat detailnya.",
      "galleryIntro": "Galeri profesional untuk foto kerja, tim, ruang rapat, acara kantor, pelatihan, dan aktivitas profesional. Ganti visual contoh dengan foto asli yang Anda miliki atau berizin untuk dibagikan.",
      "contactIntro": "Terbuka untuk diskusi profesional, kolaborasi proyek, peluang kerja, dan pertanyaan terkait portofolio.",
      "contactHeading": "Kolaborasi yang bermakna dimulai dari komunikasi yang jelas.",
      "contactBody": "Gunakan formulir untuk mengirim pesan. Pengiriman online memerlukan konfigurasi endpoint Google Apps Script.",
      "contactForm": "Formulir Kontak",
      "sendMessage": "Kirim Pesan",
      "fullName": "Nama Lengkap",
      "emailAddress": "Alamat Email Aktif",
      "company": "Perusahaan (Opsional)",
      "subject": "Subjek",
      "message": "Pesan",
      "secureForm": "Formulir Aman",
      "submitPending": "Pesan sedang dikirim…",
      "submitSuccess": "Terima kasih. Pesan telah dikirim ke endpoint pengiriman yang dikonfigurasi.",
      "submitFail": "Pesan tidak dapat dikirim. Periksa URL web app dan pengaturan email penerima.",
      "softwareIntro": "Daftar perangkat lunak yang relevan dengan pengalaman dan pelatihan. Cantumkan hanya perangkat yang benar-benar pernah digunakan.",
      "productsCount": "20 KATEGORI",
      "galleryCount": "50 GAMBAR JPG",
      "designCount": "30 VISUAL JPG",
      "submitSuccessLocal": "Pesan tersimpan di server website. Konfigurasikan Google Apps Script agar pesan diteruskan ke Gmail.",
      "designSub": "Konsep kreatif JPG",
      "interfaceLanguage": "Bahasa Antarmuka",
      "themeMode": "Mode Gelap / Terang",
      "openToOpportunities": "Terbuka untuk peluang",
      "aboutBody": "Berkomitmen pada akurasi, pelaksanaan kerja yang terstruktur, kolaborasi lintas fungsi, dan perbaikan berkelanjutan. Memadukan pemahaman operasional dengan pola pikir digital untuk mendukung konsistensi proses dan keputusan berbasis data.",
      "experienceIntro": "Sepuluh pengalaman lintas fungsi yang mencakup operasional manufaktur, implementasi sistem, dan analisis bisnis.",
      "trainingIntro": "Program pengembangan profesional dengan modul pembelajaran, alur kerja, dan hasil pembelajaran yang relevan dengan kebutuhan industri.",
      "designSubheading": "Photoshop & Desain Kreatif",
      "projectSubheading": "Proyek Digital",
      "projectIntro": "Contoh konseptual situs internal dan antarmuka aplikasi.",
      "sliderHint": "Geser secara horizontal atau gunakan tombol panah. Pilih kartu untuk melihat detail.",
      "galleryHint": "Geser menggunakan layar sentuh, tarik secara horizontal, atau gunakan tombol panah. Pilih gambar untuk memperbesar.",
      "locationLabel": "Lokasi",
      "contactLocation": " · Indonesia",
      "footerTagline": "Dirancang dengan jelas, disiapkan untuk peluang.",
      "backToTop": "Kembali ke atas ↑",
      "heroDesc": "Profesional lintas fungsi dengan pengalaman dalam dukungan sistem, pengujian kualitas, analisis komersial, pengendalian dokumen, serta koordinasi operasional.",
      "profileSummary": "Profesional lintas fungsi dengan pengalaman dalam dukungan pengembangan TI, implementasi sistem Android dan QA testing, analisis komersial, pengendalian dokumen, serta operasional manufaktur dan administrasi. Menggabungkan dukungan teknis, validasi data, analisis biaya dan harga, digitalisasi arsip, serta koordinasi lintas fungsi untuk mendukung keterlacakan informasi dan kelancaran operasional.",
      "roleTitle": "Analis Pengembangan TI, Bisnis & Operasional Komersial"
    },
    "ko": {
      "storeIntro": "일상용품, 지역 특산품, 다양한 관심사를 위한 상품과 서비스를 엄선했습니다.",
      "storeBannerTitle": "실용적이고 신선하며 의미 있는 상품을 만나보세요.",
      "storeBannerText": "지역 특산품 · 농산물 · 생활용품 · 디지털 서비스",
      "visitStore": "버르카 스토어 방문 ↗",
      "productsTitle": "상품 및 서비스",
      "productsIntro": "아래 카탈로그를 살펴보세요. 주문 전 재고, 상태 및 서비스 조건을 확인하세요.",
      "designIntro": "창의적 콘셉트, 홍보 디자인, 이미지 보정 및 디지털 프로젝트 자료입니다. JPG 이미지를 선택해 자세히 확인하세요.",
      "galleryIntro": "포트폴리오 스타일의 시각 자료와 전문 활동 예시 모음입니다. 실제로 공유 권한이 있는 사진으로 교체하세요.",
      "contactIntro": "전문적인 논의, 프로젝트 협업, 채용 기회 및 포트폴리오 관련 문의를 환영합니다.",
      "contactHeading": "의미 있는 협업은 명확한 대화에서 시작됩니다.",
      "contactBody": "양식을 사용해 메시지를 보내세요. 온라인 전송에는 Google Apps Script 설정이 필요합니다.",
      "contactForm": "문의 양식",
      "sendMessage": "메시지 보내기",
      "fullName": "성명",
      "emailAddress": "사용 중인 이메일",
      "company": "회사명(선택)",
      "subject": "제목",
      "message": "메시지",
      "secureForm": "보안 양식",
      "submitPending": "메시지를 전송 중입니다…",
      "submitSuccess": "감사합니다. 메시지가 설정된 전송 엔드포인트로 제출되었습니다.",
      "submitFail": "메시지를 전송하지 못했습니다. 웹 앱 URL과 수신 이메일 설정을 확인하세요.",
      "softwareIntro": "경험과 교육에 관련된 도구입니다. 실제로 사용한 도구만 기재하세요.",
      "productsCount": "20개 카테고리",
      "galleryCount": "JPG 이미지 45개",
      "designCount": "JPG 비주얼 30개",
      "submitSuccessLocal": "메시지가 웹사이트 서버에 저장되었습니다. Gmail 전송을 위해 Google Apps Script를 설정하세요.",
      "designSub": "창의적 JPG 콘셉트",
      "interfaceLanguage": "인터페이스 언어",
      "themeMode": "다크 / 라이트 모드",
      "openToOpportunities": "새로운 기회에 열려 있습니다",
      "aboutBody": "정확성, 체계적인 실행, 부서 간 협업 및 지속적인 개선을 중요하게 생각합니다. 실무 운영 이해와 디지털 관점을 결합하여 일관된 업무 프로세스와 데이터 기반 의사결정을 지원합니다.",
      "experienceIntro": "제조 운영, 시스템 구현, 비즈니스 분석을 아우르는 10개의 직무 경험입니다.",
      "trainingIntro": "산업 현장의 요구에 맞춘 학습 모듈, 워크플로 및 성과를 포함하는 전문성 개발 프로그램입니다.",
      "designSubheading": "Photoshop 및 크리에이티브 디자인",
      "projectSubheading": "디지털 프로젝트",
      "projectIntro": "내부 웹사이트 및 애플리케이션 인터페이스의 개념 시연입니다.",
      "sliderHint": "가로로 스와이프하거나 화살표 버튼을 사용하세요. 카드를 선택하면 세부 정보를 볼 수 있습니다.",
      "galleryHint": "터치로 스와이프하거나 가로로 드래그하고 화살표를 사용하세요. 이미지를 선택하면 확대됩니다.",
      "locationLabel": "위치",
      "contactLocation": "인도네시아 베카시",
      "footerTagline": "명확하게 설계하고 기회를 위해 준비합니다.",
      "backToTop": "맨 위로 ↑",
      "heroDesc": "시스템 지원, 품질 보증, 상업 분석, 문서 관리 및 운영 조정 경험을 갖춘 다기능 전문가입니다.",
      "profileSummary": "IT 개발 지원, Android 시스템 구현 및 QA 테스트, 상업 분석, 문서 관리, 제조 운영 및 행정 업무 경험을 갖춘 다기능 전문가입니다. 기술 지원, 데이터 검증, 비용 및 가격 분석, 디지털 기록 관리, 부서 간 협업을 통해 정보 추적성과 운영 연속성을 지원합니다.",
      "roleTitle": "IT 개발·비즈니스·상업 운영 분석가"
    },
    "ja": {
      "storeIntro": "日常の必需品、地域の特産品、さまざまな興味に応える商品とサービスを紹介します。",
      "storeBannerTitle": "実用的で新鮮な、こだわりの商品を見つけましょう。",
      "storeBannerText": "地域の名産品 · 農園の収穫物 · 日用品 · デジタルサービス",
      "visitStore": "Berkah ストアを見る ↗",
      "productsTitle": "商品・サービス",
      "productsIntro": "以下のカタログをご覧ください。注文前に在庫、状態、サービス条件をご確認ください。",
      "designIntro": "クリエイティブ案、販促ビジュアル、画像補正、デジタルプロジェクトの紹介です。JPG画像を選択すると詳細を確認できます。",
      "galleryIntro": "ポートフォリオ風のビジュアルと職場活動のイメージ集です。共有許可のある実際の写真に差し替えてください。",
      "contactIntro": "ビジネス相談、プロジェクト協業、採用機会、ポートフォリオに関するお問い合わせを歓迎します。",
      "contactHeading": "意義ある協業は、明確な対話から始まります。",
      "contactBody": "フォームからメッセージを送信できます。オンライン送信にはGoogle Apps Scriptの設定が必要です。",
      "contactForm": "お問い合わせフォーム",
      "sendMessage": "メッセージを送信",
      "fullName": "氏名",
      "emailAddress": "有効なメールアドレス",
      "company": "会社名（任意）",
      "subject": "件名",
      "message": "メッセージ",
      "secureForm": "安全なフォーム",
      "submitPending": "メッセージを送信しています…",
      "submitSuccess": "ありがとうございます。設定済みの送信エンドポイントにメッセージを送信しました。",
      "submitFail": "送信できませんでした。ウェブアプリURLと宛先メール設定を確認してください。",
      "softwareIntro": "経験や研修に関連するツールです。実際に使用したツールのみ記載してください。",
      "productsCount": "20カテゴリー",
      "galleryCount": "JPG画像45点",
      "designCount": "JPGビジュアル30点",
      "submitSuccessLocal": "メッセージはウェブサイトサーバーに保存されました。Gmailへの送信にはGoogle Apps Scriptの設定が必要です。",
      "designSub": "クリエイティブJPGコンセプト",
      "interfaceLanguage": "表示言語",
      "themeMode": "ダーク／ライトモード",
      "openToOpportunities": "新しい機会を歓迎します",
      "aboutBody": "正確性、体系的な実行、部門横断の協力、継続的な改善を重視しています。実務の理解とデジタルの視点を組み合わせ、一貫した業務プロセスとデータに基づく意思決定を支援します。",
      "experienceIntro": "製造業務、システム導入、ビジネス分析にまたがる10件の職務経験です。",
      "trainingIntro": "実務要件に沿った学習モジュール、ワークフロー、成果を含む専門能力開発プログラムです。",
      "designSubheading": "Photoshop・クリエイティブデザイン",
      "projectSubheading": "デジタルプロジェクト",
      "projectIntro": "社内Webサイトやアプリ画面のコンセプトデモです。",
      "sliderHint": "横にスワイプするか矢印ボタンを使用してください。カードを選ぶと詳細を確認できます。",
      "galleryHint": "タッチ操作や横方向のドラッグ、矢印ボタンで移動できます。画像を選ぶと拡大します。",
      "locationLabel": "所在地",
      "contactLocation": "インドネシア・ブカシ",
      "footerTagline": "明快に設計し、機会につなげる。",
      "backToTop": "トップへ戻る ↑",
      "heroDesc": "システム支援、品質保証、商業分析、文書管理、業務調整の経験を持つクロスファンクショナルな人材です。",
      "profileSummary": "IT開発支援、Androidシステム導入とQAテスト、商業分析、文書管理、製造業務および管理業務の経験を持つクロスファンクショナルな人材です。技術支援、データ検証、コスト・価格分析、記録のデジタル化、部門横断の調整を通じて、情報の追跡可能性と業務継続を支援します。",
      "roleTitle": "IT開発・ビジネス・商業運営アナリスト"
    },
    "zh": {
      "storeIntro": "精选日常用品、地方特产以及满足个人兴趣的商品与服务。",
      "storeBannerTitle": "发现实用、新鲜又贴心的精选好物。",
      "storeBannerText": "地方特产 · 农园收获 · 日常必需品 · 数字服务",
      "visitStore": "访问 Berkah 商店 ↗",
      "productsTitle": "商品与服务",
      "productsIntro": "浏览以下目录。下单前请确认库存、商品状况和服务条款。",
      "designIntro": "创意概念、推广视觉、图像修饰和数字项目展示。选择 JPG 图片可查看详情。",
      "galleryIntro": "作品集风格视觉素材及专业场景示例。请替换为您拥有或获准分享的真实照片。",
      "contactIntro": "欢迎就专业交流、项目合作、就业机会及作品集相关事宜联系。",
      "contactHeading": "有意义的合作始于清晰的沟通。",
      "contactBody": "请使用表单发送消息。在线发送需要配置 Google Apps Script 端点。",
      "contactForm": "联系表单",
      "sendMessage": "发送消息",
      "fullName": "姓名",
      "emailAddress": "有效邮箱地址",
      "company": "公司（可选）",
      "subject": "主题",
      "message": "消息内容",
      "secureForm": "安全表单",
      "submitPending": "正在发送消息…",
      "submitSuccess": "谢谢。消息已提交至已配置的发送端点。",
      "submitFail": "消息发送失败。请检查 Web App URL 和收件邮箱设置。",
      "softwareIntro": "与经验和培训相关的工具。请仅列出您实际使用过的工具。",
      "productsCount": "20 个类别",
      "galleryCount": "45 张 JPG 图片",
      "designCount": "30 张 JPG 视觉作品",
      "submitSuccessLocal": "消息已保存到网站服务器。请配置 Google Apps Script 以将消息发送至 Gmail。",
      "designSub": "创意 JPG 概念",
      "interfaceLanguage": "界面语言",
      "themeMode": "深色 / 浅色模式",
      "openToOpportunities": "欢迎职业机会",
      "aboutBody": "重视准确性、结构化执行、跨职能协作与持续改进。结合实际运营理解和数字化思维，帮助团队保持流程一致并支持数据驱动的决策。",
      "experienceIntro": "涵盖制造运营、系统实施和业务分析的十段跨职能工作经历。",
      "trainingIntro": "围绕行业实际需求设计的专业发展项目，包含结构化学习模块、工作流程与学习成果。",
      "designSubheading": "Photoshop 与创意设计",
      "projectSubheading": "数字项目",
      "projectIntro": "内部网站和应用界面的概念演示。",
      "sliderHint": "可横向滑动或使用箭头按钮。选择卡片可查看详情。",
      "galleryHint": "可触屏滑动、横向拖动或使用箭头按钮。选择图片可放大查看。",
      "locationLabel": "所在地",
      "contactLocation": "印度尼西亚勿加泗",
      "footerTagline": "以清晰为设计，为机会而打造。",
      "backToTop": "返回顶部 ↑",
      "heroDesc": "具备系统支持、质量保证、商业分析、文档控制及运营协调经验的跨职能专业人士。",
      "profileSummary": "具备 IT 开发支持、Android 系统实施与 QA 测试、商业分析、文档控制、制造运营及行政工作经验的跨职能专业人士。结合技术支持、数据验证、成本与定价分析、档案数字化及跨部门协调，支持信息可追溯性与运营连续性。",
      "roleTitle": "IT 开发、业务与商业运营分析师"
    }
  },
  "DESIGN_TRANSLATIONS": {
    "id": [
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
    ],
    "en": [
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
    ],
    "ko": [
      "브랜드 아이덴티티 탐색",
      "소셜 미디어 캠페인",
      "라이프스타일 제품 포스터",
      "에디토리얼 표지 콘셉트",
      "화장품 제품 비주얼",
      "식음료 프로모션",
      "패션 카탈로그 레이아웃",
      "이벤트 포스터 디자인",
      "미니멀 패키지 목업",
      "디지털 광고",
      "커피 브랜딩 연구",
      "스킨케어 제품 보정",
      "지역 제품 캠페인",
      "타이포그래피 구성",
      "기업 브로슈어 디자인",
      "유니폼 프로모션 비주얼",
      "소설 표지 콘셉트",
      "중고 제품 캠페인",
      "원예 제품 포스터",
      "모바일 UI 비주얼 콘셉트",
      "랜딩 페이지 아트 디렉션",
      "시즌 세일 캠페인",
      "제품 사진 보정",
      "사진 합성 연구",
      "마켓플레이스 배너",
      "인포그래픽 레이아웃",
      "로고 탐색",
      "패키지 목업",
      "웹사이트 히어로 배너",
      "크리에이티브 합성 작품"
    ],
    "ja": [
      "ブランドアイデンティティ案",
      "SNSキャンペーン",
      "ライフスタイル商品ポスター",
      "エディトリアル表紙案",
      "化粧品ビジュアル",
      "飲食プロモーション",
      "ファッションカタログレイアウト",
      "イベントポスター",
      "ミニマル包装モックアップ",
      "デジタル広告",
      "コーヒーブランディング案",
      "スキンケア商品補正",
      "地域商品キャンペーン",
      "タイポグラフィ構成",
      "企業パンフレット",
      "ジャージ販促ビジュアル",
      "小説表紙案",
      "中古品キャンペーン",
      "ガーデニング商品ポスター",
      "モバイルUIビジュアル案",
      "ランディングページ演出",
      "季節セールキャンペーン",
      "商品写真補正",
      "フォトマニピュレーション",
      "マーケットプレイスバナー",
      "インフォグラフィック",
      "ロゴ案",
      "パッケージモックアップ",
      "ウェブサイトメインバナー",
      "クリエイティブ合成作品"
    ],
    "zh": [
      "品牌形象探索",
      "社交媒体活动",
      "生活方式产品海报",
      "编辑封面概念",
      "化妆品视觉设计",
      "餐饮推广",
      "时尚目录版式",
      "活动海报设计",
      "极简包装样机",
      "数字广告",
      "咖啡品牌研究",
      "护肤产品修图",
      "本地产品推广",
      "字体构成",
      "企业宣传册设计",
      "球衣推广视觉",
      "小说封面概念",
      "二手商品推广",
      "园艺产品海报",
      "移动界面视觉概念",
      "落地页艺术指导",
      "季节促销活动",
      "产品照片修饰",
      "照片合成研究",
      "电商横幅",
      "信息图版式",
      "标志探索",
      "包装样机",
      "网站主视觉横幅",
      "创意合成作品"
    ]
  },
  "GALLERY_TRANSLATIONS": {
    "en": [
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample",
      "sample"
],
    "id": [
      "Profil Profesional",
      "Kolaborasi Tim",
      "Sesi Lokakarya",
      "Koordinasi Proyek",
      "Aktivitas Kantor",
      "Momen Pembelajaran",
      "Kunjungan Produksi",
      "Apresiasi Tim",
      "Tonggak Proyek",
      "Acara Perusahaan",
      "Diskusi Kreatif",
      "Hari Pelatihan",
      "Cuplikan Tempat Kerja",
      "Perayaan Tim",
      "Berbagi Pengetahuan",
      "Perjalanan Profesional",
      "Pertemuan Bisnis",
      "Tinjauan Teknis",
      "Pengarahan Tim",
      "Lokakarya Pelatihan",
      "Kunjungan Operasional",
      "Diskusi Proyek",
      "Pembelajaran di Tempat Kerja",
      "Aktivitas Tim",
      "Tinjauan Proses",
      "Pengembangan Profesional",
      "Pertukaran Pengetahuan",
      "Perencanaan Kolaboratif",
      "Tinjauan Kualitas",
      "Refleksi Karier",
      "Pertemuan Klien",
      "Lokakarya Digitalisasi",
      "Operasional Gudang",
      "Peninjauan Dokumen",
      "Inspeksi Kualitas",
      "Perencanaan Produk",
      "Diskusi Tim",
      "Persiapan Kantor",
      "Presentasi Bisnis",
      "Dukungan Teknis",
      "Perbaikan Proses",
      "Sesi Pembelajaran",
      "Serah Terima Proyek",
      "Keselamatan Kerja",
      "Pencapaian Karier"
    ],
    "ko": [
      "전문 프로필",
      "팀 협업",
      "워크숍 세션",
      "프로젝트 조정",
      "사무실 활동",
      "학습 순간",
      "생산 현장 방문",
      "팀 감사",
      "프로젝트 주요 단계",
      "회사 행사",
      "창의적 토론",
      "교육일",
      "직장 스냅샷",
      "팀 축하",
      "지식 공유",
      "전문 경력",
      "비즈니스 미팅",
      "기술 검토",
      "팀 브리핑",
      "교육 워크숍",
      "운영 현장 방문",
      "프로젝트 토론",
      "현장 학습",
      "팀 활동",
      "프로세스 검토",
      "전문성 개발",
      "지식 교류",
      "협업 계획",
      "품질 검토",
      "경력 회고",
      "고객 미팅",
      "디지털 전환 워크숍",
      "창고 운영",
      "문서 검토",
      "품질 검사",
      "제품 기획",
      "팀 허들",
      "사무실 준비",
      "비즈니스 발표",
      "기술 지원",
      "프로세스 개선",
      "학습 세션",
      "프로젝트 인계",
      "작업장 안전",
      "경력 이정표"
    ],
    "ja": [
      "プロフェッショナルプロフィール",
      "チーム協働",
      "ワークショップ",
      "プロジェクト調整",
      "オフィス活動",
      "学びの瞬間",
      "生産現場訪問",
      "チームへの感謝",
      "プロジェクトの節目",
      "社内イベント",
      "クリエイティブな議論",
      "研修日",
      "職場のスナップ",
      "チームのお祝い",
      "知識共有",
      "キャリアの歩み",
      "ビジネス会議",
      "技術レビュー",
      "チームブリーフィング",
      "研修ワークショップ",
      "業務現場訪問",
      "プロジェクト討議",
      "職場での学び",
      "チーム活動",
      "プロセスレビュー",
      "専門能力開発",
      "知識交流",
      "共同計画",
      "品質レビュー",
      "キャリアの振り返り",
      "顧客ミーティング",
      "デジタル化ワークショップ",
      "倉庫業務",
      "文書レビュー",
      "品質検査",
      "商品企画",
      "チームミーティング",
      "オフィス準備",
      "ビジネスプレゼン",
      "技術サポート",
      "プロセス改善",
      "学習セッション",
      "プロジェクト引き継ぎ",
      "職場安全",
      "キャリアの節目"
    ],
    "zh": [
      "专业形象",
      "团队协作",
      "工作坊活动",
      "项目协调",
      "办公室活动",
      "学习时刻",
      "生产现场参访",
      "团队致谢",
      "项目里程碑",
      "公司活动",
      "创意讨论",
      "培训日",
      "工作场景",
      "团队庆祝",
      "知识分享",
      "职业历程",
      "商务会议",
      "技术评审",
      "团队简报",
      "培训工作坊",
      "运营现场参访",
      "项目讨论",
      "工作场所学习",
      "团队活动",
      "流程评审",
      "专业发展",
      "知识交流",
      "协作规划",
      "质量评审",
      "职业回顾",
      "客户会议",
      "数字化工作坊",
      "仓库运营",
      "文件审查",
      "质量检查",
      "产品规划",
      "团队讨论",
      "办公室准备",
      "商务演示",
      "技术支持",
      "流程改进",
      "学习课程",
      "项目交接",
      "工作场所安全",
      "职业里程碑"
    ]
  },
  "SKILL_TRANSLATIONS": {
    "id": [
      {
        "title": "Pengembangan Web & Dukungan Teknis",
        "description": "Dasar pengembangan website dan alat internal, analisis kebutuhan, troubleshooting teknis, serta dukungan pengguna.",
        "tags": [
          "HTML/CSS/JavaScript",
          "PHP & MVC",
          "Dukungan sistem"
        ]
      },
      {
        "title": "Quality Assurance & Implementasi Sistem",
        "description": "Functional testing, regression testing, dukungan UAT, pengujian API, pelaporan bug, retesting, validasi data, dan dukungan implementasi.",
        "tags": [
          "Test case",
          "Siklus bug",
          "Implementasi"
        ]
      },
      {
        "title": "Analisis Bisnis & Komersial",
        "description": "COGS, costing, pricing, BEP, ROI, GPM, NPM, biaya marketplace, pengendalian biaya, riset pasar, evaluasi pemasok, dan perencanaan bisnis.",
        "tags": [
          "Biaya & harga",
          "Riset pasar",
          "Profitabilitas"
        ]
      },
      {
        "title": "Operasional, Inventaris & Administrasi",
        "description": "Pencatatan gudang, pergerakan material, stock opname, rekonsiliasi transaksi, dokumen pembelian, pelaporan, dan koordinasi lintas fungsi.",
        "tags": [
          "Kontrol inventaris",
          "Pelaporan",
          "Operasional"
        ]
      },
      {
        "title": "Document Control & Arsip Digital",
        "description": "Verifikasi dokumen, klasifikasi, penomoran, pengendalian revisi, distribusi terkendali, pengarsipan fisik dan digital, SOP/WI, serta pemeliharaan basis data.",
        "tags": [
          "Kontrol revisi",
          "Rekaman digital",
          "SOP/WI"
        ]
      },
      {
        "title": "Koordinasi & Perbaikan Proses",
        "description": "Komunikasi terstruktur, pemantauan tindak lanjut, eskalasi masalah, konsistensi prosedur, tindak lanjut operasional, dan perbaikan berkelanjutan.",
        "tags": [
          "Koordinasi",
          "Pemecahan masalah",
          "Perbaikan proses"
        ]
      }
    ],
    "ko": [
      {
        "title": "웹 개발 및 기술 지원",
        "description": "웹사이트와 내부 도구 개발 기초, 요구사항 분석, 기술 문제 해결 및 사용자 지원.",
        "tags": [
          "HTML/CSS/JavaScript",
          "PHP 및 MVC",
          "시스템 지원"
        ]
      },
      {
        "title": "품질 보증 및 시스템 구현",
        "description": "기능 및 회귀 테스트, UAT 지원, API 테스트 경험, 결함 보고, 재테스트, 데이터 검증 및 구현 지원.",
        "tags": [
          "테스트 케이스",
          "버그 라이프사이클",
          "구현"
        ]
      },
      {
        "title": "비즈니스 및 상업 분석",
        "description": "COGS, 원가 및 가격 분석, BEP, ROI, GPM, NPM, 마켓플레이스 수수료, 비용 관리, 시장 조사, 공급업체 평가 및 사업 계획.",
        "tags": [
          "원가 및 가격",
          "시장 조사",
          "수익성"
        ]
      },
      {
        "title": "운영·재고·관리",
        "description": "창고 기록, 자재 이동, 재고 실사, 거래 조정, 구매 문서, 보고 및 부서 간 협업.",
        "tags": [
          "재고 관리",
          "보고",
          "운영"
        ]
      },
      {
        "title": "문서 관리 및 디지털 아카이빙",
        "description": "문서 검증, 분류, 번호 부여, 개정 관리, 배포, 물리·디지털 보관, SOP/WI 관리 및 데이터베이스 유지.",
        "tags": [
          "개정 관리",
          "디지털 기록",
          "SOP/WI"
        ]
      },
      {
        "title": "협업 및 프로세스 개선",
        "description": "체계적인 커뮤니케이션, 후속 조치 추적, 문제 에스컬레이션, 절차 일관성 및 지속적 개선 지원.",
        "tags": [
          "협업",
          "문제 해결",
          "프로세스 개선"
        ]
      }
    ],
    "ja": [
      {
        "title": "Web開発・技術サポート",
        "description": "Webサイトや社内ツール開発の基礎、要件分析、技術トラブルシューティング、ユーザー支援。",
        "tags": [
          "HTML/CSS/JavaScript",
          "PHP・MVC",
          "システム支援"
        ]
      },
      {
        "title": "品質保証・システム導入",
        "description": "機能テスト、回帰テスト、UAT支援、APIテスト経験、不具合報告、再テスト、データ検証、導入支援。",
        "tags": [
          "テストケース",
          "不具合管理",
          "導入支援"
        ]
      },
      {
        "title": "ビジネス・商業分析",
        "description": "COGS、原価・価格分析、BEP、ROI、GPM、NPM、マーケットプレイス手数料、コスト管理、市場調査、仕入先評価、事業計画。",
        "tags": [
          "コスト・価格",
          "市場調査",
          "収益性"
        ]
      },
      {
        "title": "業務運営・在庫・管理",
        "description": "倉庫記録、資材移動、棚卸、取引照合、購買書類、報告、部門横断の調整。",
        "tags": [
          "在庫管理",
          "報告",
          "業務運営"
        ]
      },
      {
        "title": "文書管理・デジタル保管",
        "description": "文書確認、分類、採番、改訂管理、配布、紙・デジタル保管、SOP/WI管理、データベース保守。",
        "tags": [
          "改訂管理",
          "デジタル記録",
          "SOP/WI"
        ]
      },
      {
        "title": "調整・プロセス改善",
        "description": "体系的なコミュニケーション、アクション管理、問題のエスカレーション、手順の一貫性、継続的改善支援。",
        "tags": [
          "調整",
          "問題解決",
          "プロセス改善"
        ]
      }
    ],
    "zh": [
      {
        "title": "网页开发与技术支持",
        "description": "网站与内部工具开发基础、需求分析、技术故障排查及用户支持。",
        "tags": [
          "HTML/CSS/JavaScript",
          "PHP 与 MVC",
          "系统支持"
        ]
      },
      {
        "title": "质量保证与系统实施",
        "description": "功能测试、回归测试、UAT 支持、API 测试经验、缺陷报告、复测、数据验证与实施支持。",
        "tags": [
          "测试用例",
          "缺陷生命周期",
          "系统实施"
        ]
      },
      {
        "title": "业务与商业分析",
        "description": "COGS、成本与定价、BEP、ROI、GPM、NPM、平台费用、成本控制、市场研究、供应商评估及业务规划。",
        "tags": [
          "成本与定价",
          "市场研究",
          "盈利能力"
        ]
      },
      {
        "title": "运营、库存与行政管理",
        "description": "仓库记录、物料流转、盘点、交易对账、采购文件、报告及跨部门协调。",
        "tags": [
          "库存控制",
          "报告",
          "运营"
        ]
      },
      {
        "title": "文档控制与数字归档",
        "description": "文件核验、分类、编号、版本控制、受控分发、纸质与数字归档、SOP/WI 管理及数据库维护。",
        "tags": [
          "版本控制",
          "数字记录",
          "SOP/WI"
        ]
      },
      {
        "title": "协调与流程改进",
        "description": "结构化沟通、行动跟踪、问题升级、程序一致性、运营跟进与持续改进支持。",
        "tags": [
          "协调",
          "问题解决",
          "流程改进"
        ]
      }
    ]
  }
};
