<?php
declare(strict_types=1);
// Change the username and password hash before publishing this website online.
return [
    'username' => 'admin',
    'password_hash' => '$2y$12$MdPFVvwTQkVo2eZBEnP1KOOWb1VgF9YvqGVEX9SnCBESRRbRnFB1a',
];
