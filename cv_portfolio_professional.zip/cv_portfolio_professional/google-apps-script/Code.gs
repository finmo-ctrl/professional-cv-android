/**
 * Toko Berkah / CV Portfolio contact form handler.
 * Setup: set CONTACT_RECIPIENT_EMAIL to the Gmail inbox that should receive messages,
 * deploy as a Web App (Execute as: Me), then set SHEETS_WEB_APP_URL in assets/js/config.php.
 */
const CONTACT_RECIPIENT_EMAIL = 'Cindyhilda.firdaus@gmail.com'; // <-- replace this with your Gmail address
const SHEET_NAME = 'Contact Messages';
const SPREADSHEET_ID = 'https://script.google.com/macros/s/AKfycbxyKw7jhlUNIed0N-mMlkbi7j7RT6zT9PcokESqAUeUk3vAFG6zuDjNu3baaMbOrY_7/exec';
function doPost(e) {
  try {
    const raw = (e && e.postData && e.postData.contents) || '{}';
    if (raw.length > 12000) return json_({ ok: false, error: 'Payload too large' });
    const data = JSON.parse(raw);
    // Honeypot anti-spam field; legitimate users should leave it blank.
    if (String(data.website || '').trim()) return json_({ ok: true });

    const name = String(data.name || '').trim().slice(0, 120);
    const email = String(data.email || '').trim().slice(0, 160);
    const company = String(data.company || '').trim().slice(0, 160);
    const subject = String(data.subject || '').trim().slice(0, 180);
    const message = String(data.message || '').trim().slice(0, 5000);
    if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !subject || !message) {
      return json_({ ok: false, error: 'Required fields are invalid' });
    }
    if (!CONTACT_RECIPIENT_EMAIL || CONTACT_RECIPIENT_EMAIL.indexOf('vicacacan@gmail.com') !== -1) {
      return json_({ ok: false, error: 'Configure CONTACT_RECIPIENT_EMAIL first' });
    }

    const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = spreadsheet.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = spreadsheet.insertSheet(SHEET_NAME);
      sheet.appendRow(['Timestamp', 'Name', 'Email', 'Company', 'Subject', 'Message']);
      sheet.setFrozenRows(1);
    }
    const timestamp = new Date();
    sheet.appendRow([timestamp, name, email, company, subject, message]);

    const emailSubject = '[CV Website Contact] ' + subject;
    const emailBody = [
      'A new message was submitted through your CV / portfolio website.',
      '', 'Name: ' + name, 'Email: ' + email, 'Company: ' + (company || 'Not provided'),
      'Subject: ' + subject, '', 'Message:', message, '',
      'Received: ' + timestamp.toISOString()
    ].join('\n');
    MailApp.sendEmail({
      to: CONTACT_RECIPIENT_EMAIL,
      subject: emailSubject,
      body: emailBody,
      replyTo: email,
      name: 'CV Portfolio Contact Form'
    });
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: 'Submission failed' });
  }
}

function doGet() {
  return json_({ ok: true, service: 'CV Portfolio Contact Endpoint' });
}

function json_(value) {
  return ContentService.createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}
