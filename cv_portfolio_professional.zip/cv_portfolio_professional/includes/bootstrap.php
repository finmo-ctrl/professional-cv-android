<?php
declare(strict_types=1);

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$projectRoot = realpath(dirname(__DIR__)) ?: dirname(__DIR__);
$documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: $projectRoot;
$relativeRoot = '';
if (strpos($projectRoot, $documentRoot) === 0) {
    $relativeRoot = trim(str_replace(DIRECTORY_SEPARATOR, '/', substr($projectRoot, strlen($documentRoot))), '/');
}
if (!defined('CV_BASE_PATH')) {
    define('CV_BASE_PATH', '/' . ($relativeRoot !== '' ? $relativeRoot . '/' : ''));
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('CVPORTALSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (isset($_SESSION['last_activity']) && time() - (int)$_SESSION['last_activity'] > 1800) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
    }
    session_regenerate_id(true);
}
$_SESSION['last_activity'] = time();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function cv_is_authenticated(): bool {
    return !empty($_SESSION['cv_authenticated']) && $_SESSION['cv_authenticated'] === true;
}
function cv_require_auth(): void {
    if (!cv_is_authenticated()) {
        $target = CV_BASE_PATH . 'index.php';
        header('Location: ' . $target, true, 302);
        exit;
    }
}
function cv_verify_csrf(?string $token): bool {
    return is_string($token) && isset($_SESSION['csrf_token']) && hash_equals((string)$_SESSION['csrf_token'], $token);
}
