<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
if (cv_is_authenticated()) { header('Location: portfolio.php'); exit; }
$config = require __DIR__ . '/config/auth.php';
$error = '';
$lockedUntil = (int)($_SESSION['login_locked_until'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!cv_verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.';
    } elseif (time() < $lockedUntil) {
        $remaining = max(1, (int)ceil(($lockedUntil - time()) / 60));
        $error = "You have exceeded the maximum number of permitted attempts. Please try again in {$remaining} minutes.";
    } else {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if (hash_equals((string)$config['username'], $username) && password_verify($password, (string)$config['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['cv_authenticated'] = true;
            $_SESSION['cv_username'] = $username;
            $_SESSION['login_attempts'] = 0;
            unset($_SESSION['login_locked_until']);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header('Location: portfolio.php');
            exit;
        }
        $attempts = (int)($_SESSION['login_attempts'] ?? 0) + 1;
        $_SESSION['login_attempts'] = $attempts;
        if ($attempts >= 5) {
            $_SESSION['login_locked_until'] = time() + 900;
            $_SESSION['login_attempts'] = 0;
            $error = 'Your account has been temporarily locked due to multiple unsuccessful login attempts. Please try again in 15 minutes.';
        } else {
            $error = 'Authentication failed. The username or password provided is invalid.';
        }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive"><meta name="theme-color" content="#eef2f5">
<link rel="icon" type="image/jpeg" href="assets/img/favicon.jpg">
<title>Login | Personal CV Portfolio</title>
<style>
:root{color-scheme:light;--ink:#263c4d;--muted:#718494;--line:#dfe8ee;--blue:#4c718b;--bg:#edf2f5}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(circle at 10% 10%,#dce9f0 0,transparent 34%),radial-gradient(circle at 90% 85%,#d8e2e9 0,transparent 30%),linear-gradient(135deg,#f7f9fa,#e9eff3);font-family:Inter,"Segoe UI",Arial,sans-serif;color:var(--ink)}.ambient{position:fixed;border-radius:50%;filter:blur(2px);pointer-events:none;border:1px solid #fff9}.ambient.one{width:340px;height:340px;top:-120px;right:-70px;background:#ffffff30}.ambient.two{width:280px;height:280px;bottom:-110px;left:-70px;background:#91b0c21c}.login-shell{width:min(100%,440px);position:relative;background:#ffffffbd;border:1px solid #ffffffec;border-radius:28px;padding:clamp(26px,6vw,42px);box-shadow:0 28px 80px #324b5b1c;backdrop-filter:blur(24px)}.brand{display:flex;align-items:center;gap:12px;margin-bottom:32px}.monogram{width:46px;height:46px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(145deg,#456b85,#7897aa);color:white;font-weight:800;letter-spacing:-1px;box-shadow:0 8px 20px #55758d38}.brand small{display:block;color:#7f93a2;font-size:10px;font-weight:800;letter-spacing:2px}.brand strong{display:block;margin-top:4px;font-size:14px;letter-spacing:.3px}.eyebrow{font-size:10px;font-weight:800;letter-spacing:2px;color:#7792a5;text-transform:uppercase;margin:0 0 10px}h1{font-size:clamp(28px,6vw,35px);letter-spacing:-1.2px;margin:0 0 10px} .intro{color:var(--muted);font-size:13px;line-height:1.8;margin:0 0 26px}.field{display:grid;gap:8px;margin:17px 0}.field label{font-size:11px;font-weight:750;color:#536b7d}.field input{width:100%;padding:14px 15px;border:1px solid var(--line);border-radius:13px;background:#ffffffd9;color:var(--ink);font:inherit;font-size:14px;outline:none;transition:.2s}.field input:focus{border-color:#8eacbf;box-shadow:0 0 0 4px #7a9bb41c}.password-wrap{position:relative}.password-wrap input{padding-right:76px}.toggle{position:absolute;right:7px;top:7px;border:0;border-radius:9px;padding:7px 9px;background:#edf3f6;color:#5a768a;font-size:10px;font-weight:800;cursor:pointer}.submit{width:100%;display:flex;justify-content:center;align-items:center;gap:10px;margin-top:23px;padding:14px 18px;border:0;border-radius:13px;background:linear-gradient(120deg,#3e617a,#64859c);color:white;font-size:13px;font-weight:800;cursor:pointer;box-shadow:0 10px 22px #486c852e}.submit:hover{filter:brightness(1.04);transform:translateY(-1px)}.error{padding:12px 13px;border-radius:12px;background:#fff0ee;border:1px solid #f2d1cc;color:#9a4439;font-size:12px;line-height:1.6;margin-bottom:15px}.security{display:flex;gap:10px;align-items:flex-start;border-top:1px solid #e7edf1;margin-top:25px;padding-top:18px;color:#8293a0;font-size:10px;line-height:1.7}.lock{font-size:15px}.foot{text-align:center;color:#9aa7b0;font-size:9px;letter-spacing:.3px;margin:23px 0 0}@media(max-width:480px){body{padding:14px}.login-shell{border-radius:22px;padding:25px 21px}}
</style>
</head><body><div class="ambient one"></div><div class="ambient two"></div><main class="login-shell">
<div class="brand"><div class="monogram">CV</div><div><small>PRIVATE WORKSPACE</small><strong>Personal CV & Portfolio</strong></div></div>
<p class="eyebrow">Restricted access</p><h1>Welcome Back Cindy</h1><p class="intro">Please sign in to access your personal CV and portfolio.</p>
<?php if ($error !== ''): ?><div class="error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<form method="post" action="index.php" autocomplete="on">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)$_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
<div class="field"><label for="username">Username</label><input id="username" name="username" type="text" autocomplete="username" required maxlength="80" autofocus></div>
<div class="field"><label for="password">Password</label><div class="password-wrap"><input id="password" name="password" type="password" autocomplete="current-password" required maxlength="200"><button class="toggle" type="button" id="togglePassword" aria-label="Tampilkan password">Show Password</button></div></div>
<button class="submit" type="submit">Login securely <span aria-hidden="true">→</span></button></form>
<div class="security"><span class="lock" aria-hidden="true">▣</span><span>Your access is protected by an authenticated session. For your security, your session will automatically expire after a period of inactivity.</span></div>
<p class="foot">PRIVATE ACCESS · PERSONAL INFORMATION PROTECTION</p></main><script>document.getElementById('togglePassword').addEventListener('click',function(){const p=document.getElementById('password');const show=p.type==='password';p.type=show?'text':'password';this.textContent=show?'Hide Password':'Show Tampilkan';this.setAttribute('aria-label',show?'Hide Password':'Show password');});</script></body></html>
