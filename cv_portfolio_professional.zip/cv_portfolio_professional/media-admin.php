<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
cv_require_auth();

$groups = [
  'reference' => ['label' => 'Profile / Hero Photos', 'path' => __DIR__ . '/assets/img/reference'],
  'designs' => ['label' => 'Design Portfolio', 'path' => __DIR__ . '/assets/img/designs'],
  'gallery' => ['label' => 'Gallery', 'path' => __DIR__ . '/assets/img/gallery'],
  'certificates' => ['label' => 'Certificates', 'path' => __DIR__ . '/assets/img/certificates'],
  'icons' => ['label' => 'Skill & Menu Icons', 'path' => __DIR__ . '/assets/img/icons'],
  'products' => ['label' => 'Store Products', 'path' => __DIR__ . '/assets/img/products'],
  'projects' => ['label' => 'Project Images', 'path' => __DIR__ . '/assets/img/projects'],
];
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!cv_verify_csrf(isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : null)) {
    $error = 'Invalid security token. Reload this page and try again.';
  } else {
    $group = isset($_POST['group']) ? (string)$_POST['group'] : '';
    $target = isset($_POST['target']) ? basename((string)$_POST['target']) : '';
    if (!isset($groups[$group]) || !preg_match('/^[A-Za-z0-9._-]+\.jpg$/i', $target)) {
      $error = 'Choose a valid image and destination.';
    } elseif (!isset($_FILES['image']) || !is_uploaded_file($_FILES['image']['tmp_name'])) {
      $error = 'Select a JPG image to upload.';
    } elseif ($_FILES['image']['error'] !== UPLOAD_ERR_OK || (int)$_FILES['image']['size'] > 8 * 1024 * 1024) {
      $error = 'Upload failed or file exceeds the 8 MB limit.';
    } else {
      $dir = $groups[$group]['path'];
      $destination = $dir . DIRECTORY_SEPARATOR . $target;
      $info = @getimagesize($_FILES['image']['tmp_name']);
      $mime = function_exists('finfo_open') ? (function () { $f = finfo_open(FILEINFO_MIME_TYPE); $m = $f ? finfo_file($f, $_FILES['image']['tmp_name']) : ''; if ($f) finfo_close($f); return $m; })() : (isset($info['mime']) ? $info['mime'] : '');
      if ($mime !== 'image/jpeg' || !$info || !is_file($destination) || !is_writable($dir)) {
        $error = 'Only valid JPG files can replace an existing image. Check folder write permission.';
      } elseif (!move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
        $error = 'Could not save the image. Check folder write permission.';
      } else {
        @chmod($destination, 0644);
        $message = 'Image replaced and saved permanently: ' . htmlspecialchars($group . '/' . $target, ENT_QUOTES, 'UTF-8');
      }
    }
  }
}
$selectedGroup = isset($_POST['group']) && isset($groups[$_POST['group']]) ? (string)$_POST['group'] : 'reference';
$files = [];
foreach ($groups as $key => $group) {
  $files[$key] = [];
  if (is_dir($group['path'])) {
    foreach (scandir($group['path']) as $name) {
      if ($name !== '.' && $name !== '..' && preg_match('/\.jpg$/i', $name) && is_file($group['path'] . DIRECTORY_SEPARATOR . $name)) $files[$key][] = $name;
    }
  }
  sort($files[$key]);
}
$selectedTarget = isset($_POST['target']) ? basename((string)$_POST['target']) : (isset($files[$selectedGroup][0]) ? $files[$selectedGroup][0] : '');
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Manage Portfolio Photos</title>
<style>body{font-family:Arial,sans-serif;background:#f2f4f6;color:#26313a;margin:0;padding:25px}.wrap{max-width:760px;margin:30px auto;background:#fff;border:1px solid #dce1e5;border-radius:12px;padding:26px;box-shadow:0 8px 30px rgba(0,0,0,.06)}h1{font-size:24px;margin-top:0}.muted{color:#66727d;line-height:1.6}.field{margin:18px 0}label{display:block;font-weight:bold;margin-bottom:7px}select,input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #cbd3da;border-radius:7px;background:#fff;font-size:15px}button,.back{display:inline-block;background:#273b46;color:white;border:0;border-radius:7px;padding:12px 18px;text-decoration:none;cursor:pointer;font-size:14px}.notice{padding:12px;border-radius:7px;background:#e9f6ed;color:#176333}.error{padding:12px;border-radius:7px;background:#fff0ef;color:#9c2923}.hint{font-size:13px;color:#697681}.actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}</style></head><body><main class="wrap">
<h1>Manage CV Website Photos</h1><p class="muted">Replace an existing image with a JPG file. The replacement is saved directly to the website folder, so it remains after logout, login, or browser restart. Existing image names and page references stay unchanged.</p>
<?php if ($message !== ''): ?><p class="notice"><?= $message ?></p><?php endif; ?>
<?php if ($error !== ''): ?><p class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)$_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
<div class="field"><label for="group">Image category</label><select name="group" id="group" onchange="this.form.submit()">
<?php foreach ($groups as $key => $group): ?><option value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"<?= $selectedGroup === $key ? ' selected' : '' ?>><?= htmlspecialchars($group['label'], ENT_QUOTES, 'UTF-8') ?> (<?= count($files[$key]) ?>)</option><?php endforeach; ?></select><p class="hint">Changing the category reloads the available filenames.</p></div>
<div class="field"><label for="target">Replace which existing image?</label><select name="target" id="target"><?php foreach ($files[$selectedGroup] as $name): ?><option value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"<?= $selectedTarget === $name ? ' selected' : '' ?>><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></div>
<div class="field"><label for="image">Choose replacement JPG</label><input type="file" name="image" id="image" accept=".jpg,.jpeg,image/jpeg" required><p class="hint">JPG/JPEG only · Maximum 8 MB · The selected existing file will be overwritten.</p></div>
<div class="actions"><button type="submit">Upload & Replace Image</button><a class="back" href="portfolio.php">Back to CV Website</a></div>
</form><p class="hint">If upload fails, make sure the selected destination folder is writable by Apache. Back up the original JPG before replacing it.</p>
</main></body></html>
