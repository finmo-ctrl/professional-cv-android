<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
cv_require_auth();
$file = (string)($_GET['file'] ?? '');
if (!preg_match('~^(reference|designs|gallery|certificates)/([A-Za-z0-9._-]+\.jpg)$~i', $file, $m)) {
    http_response_code(404); exit('Not found');
}
$folder = strtolower($m[1]);
$name = basename($m[2]);
$path = __DIR__ . '/assets/img/' . $folder . '/' . $name;
if (!is_file($path)) { http_response_code(404); exit('Not found'); }
header('Content-Type: image/jpeg');
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: inline; filename="' . $name . '"');
readfile($path);
