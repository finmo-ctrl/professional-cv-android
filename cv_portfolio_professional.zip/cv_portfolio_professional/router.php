<?php
declare(strict_types=1);
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$blocked = [
    '~^/private_media(?:/|$)~i',
    '~^/assets/img/(?:certificates|designs|gallery|reference)(?:/|$)~i',
    '~^/config(?:/|$)~i',
    '~^/includes(?:/|$)~i',
    '~^/data(?:/|$)~i',
];
foreach ($blocked as $pattern) {
    if (preg_match($pattern, $path)) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Not found';
        exit;
    }
}
$file = __DIR__ . $path;
if ($path !== '/' && is_file($file) && realpath($file) !== false && strpos(realpath($file), realpath(__DIR__) . DIRECTORY_SEPARATOR) === 0) {
    return false;
}
require __DIR__ . '/index.php';
